# Guía de adaptación para ASP.NET

## Objetivo

Este prototipo representa una propuesta de interfaz para modernizar el módulo ACH - ODD sin cambiar el proceso de negocio: afiliación masiva, validación, aprobación, procesamiento y trazabilidad.

## Estructura visual

- Barra superior institucional: logo, notificaciones y usuario.
- Menú lateral: Resumen, Afiliaciones, Cargas y débitos, Aprobaciones, Consultas y reportes.
- Resumen: indicadores, actividad, tareas pendientes y últimas cargas.
- Modal Nueva carga: tipo de operación, empresa, archivo y validación.

## Rutas ASP.NET sugeridas

```text
/Main/Resumen
/Credicargo/Affiliation
/Credicargo/Affiliation/MassUpload
/Credicargo/Debits
/Credicargo/Batches
/Credicargo/Batches/Review/{batchId}
/Credicargo/Reports
/Admin/Users
/Admin/Roles
```

## Modelo de datos mínimo

### Batch / Lote

- `BatchId` o `BatchCode`
- `OperationType`: AFFILIATION | DEBIT
- `CompanyId`
- `CollectorAccountId`
- `OriginalFileName`
- `TotalRecords`
- `ValidRecords`
- `ObservedRecords`
- `RejectedRecords`
- `TotalAmount`
- `Status`
- `CreatedBy`
- `CreatedAt`
- `ValidatedBy`, `ValidatedAt`
- `ApprovedBy`, `ApprovedAt`
- `ProcessedAt`
- `RejectionReason`

### BatchRecord / Registro del lote

- `BatchRecordId`
- `BatchId`
- `DocumentType`
- `DocumentNumber`
- `CustomerName`
- `BankAccount`
- `Amount`
- `DebitDate`
- `AffiliationCode`
- `Status`
- `Observation`

### AuditEvent / Auditoría

- `AuditEventId`
- `BatchId`
- `Action`
- `PreviousStatus`
- `NewStatus`
- `UserId`
- `CreatedAt`
- `Comment`
- `IpAddress`

## Estados recomendados

```text
DRAFT
VALIDATING
OBSERVED
PENDING_APPROVAL
APPROVED
PROCESSING
PROCESSED
REJECTED
CANCELLED
```

La transición de estado debe estar controlada en servidor. El perfil Operador no debe poder aprobar sus propias cargas.

## Endpoints sugeridos

```http
GET    /api/batches?status=&search=&page=&pageSize=
POST   /api/batches
POST   /api/batches/{id}/validate
GET    /api/batches/{id}/records
GET    /api/batches/{id}/errors
POST   /api/batches/{id}/approve
POST   /api/batches/{id}/return
POST   /api/batches/{id}/reject
POST   /api/batches/{id}/process
POST   /api/batches/{id}/cancel
GET    /api/batches/{id}/audit
GET    /api/affiliations?document=&companyId=&status=
```

Para cargas grandes, `POST /validate` puede responder con un identificador de proceso y ejecutarse como tarea en segundo plano. El front debe consultar el estado o recibir una notificación cuando termine.

## Perfiles y permisos

El prototipo incluye un selector de perfil para demostrar permisos en pantalla. En ASP.NET debe reemplazarse por la identidad y los claims reales del usuario; el selector de demo no debe existir en producción.


| Permiso | Operador | Validador | Autorizador | Supervisor | Administrador |
|---|---:|---:|---:|---:|---:|
| Crear carga | Sí | Sí | No | Sí | Sí |
| Ver registros | Sí | Sí | Sí | Sí | Sí |
| Validar carga | No | Sí | Sí | Sí | Sí |
| Aprobar carga | No | No | Sí | Sí | Sí |
| Reprocesar observados | No | Sí | No | Sí | Sí |
| Anular carga | No | No | No | Sí | Sí |
| Gestionar usuarios | No | No | No | No | Sí |

## Reglas de validación

1. Validar extensión, tamaño máximo y estructura del archivo.
2. Validar campos obligatorios y tipos de documento permitidos.
3. Validar duplicados dentro del archivo y contra afiliaciones existentes.
4. Validar empresa, cuenta recaudadora y cuenta bancaria.
5. Validar montos positivos, fechas y límites configurables.
6. Separar registros correctos, observados y rechazados.
7. Generar archivo descargable con fila, campo, código y descripción del error.
8. No guardar ni procesar un lote que no tenga resultado de validación.

## Integración en Razor / MVC

Puedes reemplazar progresivamente la vista actual con estos bloques:

- `Shared/_Topbar.cshtml`
- `Shared/_Sidebar.cshtml`
- `Credicargo/Resumen.cshtml`
- `Credicargo/_BatchTable.cshtml`
- `Credicargo/_UploadModal.cshtml`
- `Credicargo/_StatusBadge.cshtml`

Conserva las URLs existentes y adapta los nombres de campos del modelo. Si usas Web Forms, los mismos bloques pueden convertirse en User Controls (`.ascx`).

## Recomendaciones de implementación

- Mantener validaciones críticas en backend; JavaScript solo mejora la experiencia.
- Registrar auditoría para cada cambio de estado.
- Aplicar paginación del lado servidor.
- Utilizar antiforgery tokens en formularios y endpoints mutables.
- Limitar tamaño, extensión y contenido de archivos.
- No mostrar cuentas bancarias completas en tablas; enmascarar parte de la cuenta.
- Deshabilitar acciones según permisos, pero validar autorización nuevamente en servidor.
- Añadir exportación de resultados y descarga de errores.
- Usar mensajes con código de lote para facilitar soporte.

## Migración por fases

1. Crear roles y permisos sin modificar el procesamiento actual.
2. Crear tabla de lotes y auditoría.
3. Incorporar carga masiva y validación previa.
4. Habilitar bandeja de revisión y autorización.
5. Migrar el procesamiento de débitos a estados y lotes.
6. Retirar el alta individual solo después de validar equivalencia funcional.

## Datos de ejemplo del prototipo

Los datos visibles en la interfaz son demostrativos. En ASP deben reemplazarse por llamadas a tus controladores, servicios o APIs existentes; no deben copiarse como información productiva.
