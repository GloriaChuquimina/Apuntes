# Sistema de Administración BCP - Guía de Usuario

## 📋 Descripción General

Sistema web de administración para operaciones ACH del Banco Central de Bolivia (BCP), con gestión de usuarios, límites, participantes y liquidaciones por ciclo.

---

## 🎯 Módulos Disponibles

### 1. **ADMINISTRACIÓN DE USUARIOS**
**Ruta:** `/` (Inicio)

**Funcionalidades:**
- Listar todos los usuarios del sistema
- Buscar usuarios por nombre, matrícula o correo
- Ver detalles completos de cada usuario en modal
- Auditoría: Usuario creador y fechas de modificación

**Información mostrada en tabla:**
- Usuario | Email | Celular | Estado | Acción

**Información en Modal de Detalle:**
- Datos personales completos
- Número de documento
- Estado del usuario
- Información de auditoría (creador, modificador, fechas)
- Botones: Cerrar, Editar, Eliminar

**Badges de Estado:**
- 🟢 Habilitado (Verde)
- 🔴 Deshabilitado (Rojo)

---

### 2. **CONTROL DE LÍMITES**
**Ruta:** `/limites`

**Funcionalidades:**
- Monitoreo de límites por participante
- Visualización de porcentaje de uso con barra progresiva
- Búsqueda por código, participante o moneda
- Alertas visuales por nivel de utilización

**Información mostrada en tabla:**
- Código | Participante | Moneda | Monto Límite | Uso % | Estado | Acción

**Indicadores de Uso (% Utilización):**
- 🟢 Verde: 0-50% (Normal)
- 🟡 Amarillo: 51-80% (Advertencia)
- 🟠 Naranja: 81-95% (Crítico)
- 🔴 Rojo: 96-100% (Límite alcanzado)

**Información en Modal de Detalle:**
- Código del participante
- Nombre del participante
- Moneda de operación
- Monto límite
- Balance usado
- Porcentaje de uso (con barra visual)
- Estado (Activo/Advertencia/Crítico)
- Usuario creador
- Fecha de modificación
- Botones: Cerrar, Editar

---

### 3. **GESTIÓN DE PARTICIPANTES**
**Ruta:** `/participantes`

**Funcionalidades:**
- Administración de instituciones participantes
- Búsqueda por código, nombre o ciudad
- Visualización de estado de cada participante
- Información de contacto

**Información mostrada en tabla:**
- Código | Nombre | Tipo | Ciudad | Estado | Cuentas Activas | Acción

**Tipos de Participantes:**
- 🏦 Banco
- 🏢 Cooperativa
- 💼 Empresa

**Estados:**
- 🟢 Activo (Verde)
- 🟡 Suspendido (Rojo)
- ⚪ Inactivo (Gris)

**Información en Modal de Detalle:**
- Código
- Nombre
- Tipo de participante
- Ciudad
- Email (con ícono)
- Teléfono (con ícono)
- Estado
- Operaciones del mes
- Cuentas activas
- Usuario creador
- Botones: Cerrar, Editar

---

### 4. **LIQUIDACIÓN POR CICLO**
**Ruta:** `/liquidacion`

**Dashboard Superior (4 Cards):**
- Ciclos Liquidados: 2
- En Proceso: 1
- Pendientes: 1
- Total Operaciones: 13,800

**Funcionalidades:**
- Gestión de ciclos de liquidación
- Búsqueda por número de ciclo o fecha
- Visualización de estadísticas por ciclo

**Información mostrada en tabla:**
- Ciclo | Período | Operaciones | Monto Total | Participantes | Estado | Acción

**Estados del Ciclo:**
- 🟢 Completado (Verde)
- 🟡 En Proceso (Amarillo)
- ⚪ Pendiente (Gris)

**Información en Modal de Detalle:**
- Número de ciclo
- Período (Fecha inicio - Fecha fin)
- Total de operaciones
- Monto total liquidado
- Participantes involucrados
- Estado actual
- Detalles financieros:
  - Monto en entrada
  - Monto en salida
  - Neto
- Información de auditoría
- Botones: Cerrar, Editar, Descargar

---

## 🎨 Paleta de Colores BCP

| Color | Código | Uso |
|-------|--------|-----|
| **Navy** | #001B41 | Menú, títulos, acentos |
| **Naranja** | #FF6600 | Botones primarios, estado activo |
| **Azul** | #0061BD | Botones secundarios, links |
| **Verde** | #2D9C3E | Botón "Nuevo", estados positivos |
| **Rojo** | #DC2626 | Botón eliminar, estados críticos |
| **Fondo** | #F5F7FA | Fondo general |

---

## 🔒 Características de Seguridad

✅ **Información Jerárquica**
- Lista: Solo datos esenciales
- Modal: Información completa y sensitiva

✅ **Auditoría Completa**
- Usuario creador registrado
- Fechas de creación y modificación
- Usuario modificador

✅ **Indicadores Visuales**
- Badges para estados
- Barras de progreso para utilización
- Colores codificados por riesgo

✅ **Controles de Acceso**
- Navegación segura con rutas
- Validación en cliente

---

## 🧭 Navegación

**Menú Lateral (Siempre visible):**
- 🏠 Inicio → Usuarios
- 👥 Usuarios → Administración de usuarios
- 💰 Límites → Control de límites
- 🏢 Participantes → Gestión de participantes
- 📊 Liquidación → Liquidación por ciclo
- 🚪 Salir → Cerrar sesión

**El botón del menú permite colapsarlo para más espacio**

---

## 📱 Responsividad

- **Menú lateral colapsable:** Click en el ícono hamburguesa
- **Tablas:** Scroll horizontal en dispositivos pequeños
- **Modales:** Optimizados para todas las pantallas
- **Búsqueda:** Activa en todas las pantallas

---

## 🚀 Cómo Usar Cada Pantalla

### Usuarios
1. Ve a **Inicio** → **Usuarios**
2. Usa el buscador para filtrar
3. Haz clic en el ícono de ojo para ver detalles
4. En el modal, puedes editar o eliminar

### Límites
1. Ve a **Límites**
2. Observa la barra de progreso para % de uso
3. Los colores indican el nivel de riesgo
4. Haz clic en el ícono de ojo para detalles completos

### Participantes
1. Ve a **Participantes**
2. Busca por código, nombre o ciudad
3. Verifica el estado en la tabla
4. Abre el modal para contacto y detalles

### Liquidación
1. Ve a **Liquidación**
2. Observa el dashboard con estadísticas
3. Busca ciclos por número o fecha
4. Abre detalles para información financiera

---

## 💡 Consejos y Mejores Prácticas

1. **Búsqueda regular:** Usa los buscadores para encontrar rápidamente registros
2. **Monitoreo de límites:** Revisa regularmente los % de uso para evitar críticos
3. **Estados:** Presta atención a los colores para identificar rápidamente problemas
4. **Auditoría:** Verifica quién y cuándo se realizaron cambios
5. **Modales:** Lee toda la información disponible en los modales de detalle

---

## ⚠️ Estados Críticos

**Límites en Rojo (Crítico):** Acción requerida inmediata
**Participante Suspendido:** No operativo
**Ciclo Pendiente:** Requiere procesamiento

---

## 📞 Soporte

Para reportes de bugs o sugerencias, contacta al equipo de desarrollo.

---

**Última actualización:** 2024-03-20
**Versión:** 1.0.0
**Sistema:** BCP - Administrador de Interoperabilidad OR
