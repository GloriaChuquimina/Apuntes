# Guía de implementación Blazor: Transacciones ACH

## 1. Objetivo

Esta guía documenta la implementación Blazor de la funcionalidad diseñada para el backoffice ACH:

- Consulta de transacciones procesadas.
- Filtros globales por fecha, ciclo, número de orden y número ACH.
- Búsqueda con o sin filtros.
- Exportación CSV con o sin filtros.
- Tabla operativa con todas las columnas de la captura.
- Enlace del número ACH hacia el detalle completo de la orden.
- Detalle de orden ACH en página independiente.
- Detalle de orden ACH en modal.
- Mensajes relacionados de origen y destino.
- Bloques de Datos generales, Originante y Destinatario.
- Visualización del XML de mensajes.

La estructura funciona en Blazor Server y Blazor WebAssembly. En producción, los datos deben provenir de una API protegida; los ejemplos de esta guía son contratos de referencia.

---

## 2. Estructura recomendada

```text
Features/
└── Transacciones/
    ├── Models/
    │   ├── TransaccionDto.cs
    │   ├── TransaccionFilter.cs
    │   ├── TransaccionResult.cs
    │   ├── OrdenAchDetalleDto.cs
    │   └── MensajeAchDto.cs
    ├── Services/
    │   ├── ITransaccionesService.cs
    │   └── TransaccionesService.cs
    └── Pages/
        ├── Transacciones.razor
        ├── Transacciones.razor.cs
        ├── OrdenAch.razor
        └── OrdenAch.razor.cs

Shared/Components/
├── Modal.razor
├── InfoBlock.razor
├── XmlViewer.razor
└── LoadingIndicator.razor
```

---

## 3. Modelo de transacción

Crea `Models/TransaccionDto.cs`:

```csharp
namespace BcpAch.Features.Transacciones.Models;

public sealed class TransaccionDto
{
    public long Id { get; set; }
    public DateTime Fecha { get; set; }
    public string NumeroOriginante { get; set; } = string.Empty;
    public string NumeroAch { get; set; } = string.Empty;
    public string HoraInicio { get; set; } = string.Empty;
    public string HoraFin { get; set; } = string.Empty;
    public string ParticipanteOrigen { get; set; } = string.Empty;
    public string ParticipanteDestino { get; set; } = string.Empty;
    public string EstadoOperacion { get; set; } = string.Empty;
    public string CodigoIntento { get; set; } = string.Empty;
    public decimal Importe { get; set; }
    public string Moneda { get; set; } = "BOB";
    public string EtapaOperacion { get; set; } = string.Empty;
    public string Ciclo { get; set; } = string.Empty;
    public string NumeroOrden { get; set; } = string.Empty;
    public string Tipo { get; set; } = string.Empty;
    public string Referencia { get; set; } = string.Empty;
}
```

### Estados recomendados

```text
ACEP      Operación aceptada
PEND      Pendiente de respuesta
RECH      Rechazada
ERR       Error técnico o de negocio
OBS       Observada
```

No se debe asumir que todos los estados son exitosos solo por recibir una respuesta. La API debe definir el catálogo oficial de estados.

---

## 4. Filtros globales

Crea `Models/TransaccionFilter.cs`:

```csharp
namespace BcpAch.Features.Transacciones.Models;

public sealed class TransaccionFilter
{
    public bool FiltrosActivos { get; set; }
    public DateTime? Fecha { get; set; }
    public string Ciclo { get; set; } = string.Empty;
    public string NumeroOrden { get; set; } = string.Empty;
    public string NumeroAch { get; set; } = string.Empty;
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
```

La interfaz debe mostrar un único checkbox `FiltrosActivos`. Cuando está desmarcado:

- Los campos pueden quedar deshabilitados.
- La consulta no debe enviar criterios de búsqueda.
- Buscar debe cargar el listado general.
- Exportar debe exportar todos los registros permitidos.

Cuando está marcado, se envían los valores introducidos en fecha, ciclo, orden y ACH. No es necesario activar cada campo por separado.

---

## 5. Resultado paginado

```csharp
public sealed class TransaccionResult
{
    public IReadOnlyList<TransaccionDto> Items { get; set; } = [];
    public int Total { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
}
```

La API debe devolver el total real para evitar cargar todos los registros en el navegador.

---

## 6. Servicio HTTP

### Interfaz

```csharp
public interface ITransaccionesService
{
    Task<TransaccionResult> BuscarAsync(
        TransaccionFilter filtro,
        CancellationToken cancellationToken = default);

    Task<byte[]> ExportarAsync(
        TransaccionFilter filtro,
        CancellationToken cancellationToken = default);

    Task<OrdenAchDetalleDto> ObtenerOrdenAsync(
        string numeroAch,
        CancellationToken cancellationToken = default);
}
```

### Implementación

```csharp
public sealed class TransaccionesService(HttpClient http) : ITransaccionesService
{
    public async Task<TransaccionResult> BuscarAsync(
        TransaccionFilter filtro,
        CancellationToken cancellationToken = default)
    {
        var query = new List<string>
        {
            $"page={filtro.Page}",
            $"pageSize={filtro.PageSize}"
        };

        if (filtro.FiltrosActivos)
        {
            if (filtro.Fecha.HasValue)
                query.Add($"fecha={Uri.EscapeDataString(filtro.Fecha.Value.ToString("yyyy-MM-dd"))}");
            if (!string.IsNullOrWhiteSpace(filtro.Ciclo))
                query.Add($"ciclo={Uri.EscapeDataString(filtro.Ciclo)}");
            if (!string.IsNullOrWhiteSpace(filtro.NumeroOrden))
                query.Add($"numeroOrden={Uri.EscapeDataString(filtro.NumeroOrden)}");
            if (!string.IsNullOrWhiteSpace(filtro.NumeroAch))
                query.Add($"numeroAch={Uri.EscapeDataString(filtro.NumeroAch)}");
        }

        var url = $"api/transacciones?{string.Join("&", query)}";
        return await http.GetFromJsonAsync<TransaccionResult>(url, cancellationToken)
            ?? new TransaccionResult();
    }

    public Task<byte[]> ExportarAsync(
        TransaccionFilter filtro,
        CancellationToken cancellationToken = default)
    {
        // La API debe generar el archivo y aplicar los mismos filtros del listado.
        return http.GetByteArrayAsync("api/transacciones/export", cancellationToken);
    }

    public async Task<OrdenAchDetalleDto> ObtenerOrdenAsync(
        string numeroAch,
        CancellationToken cancellationToken = default)
    {
        return await http.GetFromJsonAsync<OrdenAchDetalleDto>(
            $"api/transacciones/ordenes/{Uri.EscapeDataString(numeroAch)}",
            cancellationToken) ?? new OrdenAchDetalleDto();
    }
}
```

Registra el servicio en `Program.cs`:

```csharp
builder.Services.AddScoped<ITransaccionesService, TransaccionesService>();
```

En Blazor WebAssembly usa un `HttpClient` configurado con la URL de la API. Nunca construyas consultas SQL desde el componente.

---

## 7. Página `Transacciones.razor`

```razor
@page "/transacciones"
@inject ITransaccionesService TransaccionesService
@inject IJSRuntime JS

<PageTitle>Transacciones ACH</PageTitle>

<h1>Transacciones</h1>
<p class="text-muted">Consulta las operaciones más recientes procesadas por el ACH.</p>

<section class="filter-card">
    <div class="filter-header">
        <div>
            <h2>Filtros de búsqueda</h2>
            <p>Activa o desactiva todos los criterios desde un solo control.</p>
        </div>
        <label class="global-filter">
            <input type="checkbox" @bind="Filtro.FiltrosActivos" />
            Activar filtros
        </label>
    </div>

    <div class="filter-grid">
        <label>
            Fecha
            <InputDate @bind-Value="Filtro.Fecha" disabled="@(!Filtro.FiltrosActivos)" />
        </label>
        <label>
            Ciclo
            <InputText @bind-Value="Filtro.Ciclo" disabled="@(!Filtro.FiltrosActivos)" placeholder="Buscar ciclo" />
        </label>
        <label>
            Número de orden
            <InputText @bind-Value="Filtro.NumeroOrden" disabled="@(!Filtro.FiltrosActivos)" placeholder="Ingrese número" />
        </label>
        <label>
            Número ACH
            <InputText @bind-Value="Filtro.NumeroAch" disabled="@(!Filtro.FiltrosActivos)" placeholder="Ingrese número" />
        </label>
    </div>

    <div class="actions">
        <button class="btn-primary" @onclick="BuscarAsync">Buscar</button>
        <button class="btn-success" @onclick="ExportarAsync">Exportar</button>
    </div>
</section>

@if (Loading)
{
    <LoadingIndicator />
}
else if (!string.IsNullOrWhiteSpace(ErrorMessage))
{
    <div class="alert-error">@ErrorMessage</div>
}
else
{
    <p>Mostrando @Resultado.Items.Count registros. Total: @Resultado.Total</p>

    <div class="table-responsive">
        <table class="operations-table">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Número originante</th>
                    <th>Número ACH</th>
                    <th>Hora inicio</th>
                    <th>Hora fin</th>
                    <th>Participante origen</th>
                    <th>Participante destino</th>
                    <th>Estado operación</th>
                    <th>Código intento</th>
                    <th>Importe</th>
                    <th>Moneda</th>
                    <th>Etapa operación</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                @foreach (var item in Resultado.Items)
                {
                    <tr>
                        <td>@item.Fecha.ToString("dd/MM/yyyy")</td>
                        <td>@item.NumeroOriginante</td>
                        <td>
                            <a href="/transacciones/orden?ach=@Uri.EscapeDataString(item.NumeroAch)">
                                @item.NumeroAch
                            </a>
                        </td>
                        <td>@item.HoraInicio</td>
                        <td>@item.HoraFin</td>
                        <td>@item.ParticipanteOrigen</td>
                        <td>@item.ParticipanteDestino</td>
                        <td><StatusBadge Value="@item.EstadoOperacion" /></td>
                        <td>@item.CodigoIntento</td>
                        <td>@item.Importe.ToString("N2")</td>
                        <td>@item.Moneda</td>
                        <td>@item.EtapaOperacion</td>
                        <td>
                            <button class="btn-icon" @onclick="() => AbrirDetalle(item)">
                                Detalle de orden
                            </button>
                        </td>
                    </tr>
                }
            </tbody>
        </table>
    </div>
}

@if (OrdenSeleccionada is not null)
{
    <OrdenAchModal Orden="OrdenSeleccionada" OnClose="CerrarDetalle" />
}
```

---

## 8. Code-behind

`Transacciones.razor.cs`:

```csharp
public partial class Transacciones
{
    protected TransaccionFilter Filtro { get; } = new();
    protected TransaccionResult Resultado { get; set; } = new();
    protected OrdenAchDetalleDto? OrdenSeleccionada { get; set; }
    protected bool Loading { get; set; }
    protected string ErrorMessage { get; set; } = string.Empty;

    protected override async Task OnInitializedAsync()
    {
        await BuscarAsync();
    }

    protected async Task BuscarAsync()
    {
        await ExecuteAsync(async () =>
        {
            Filtro.Page = 1;
            Resultado = await TransaccionesService.BuscarAsync(Filtro);
        });
    }

    protected async Task ExportarAsync()
    {
        await ExecuteAsync(async () =>
        {
            var bytes = await TransaccionesService.ExportarAsync(Filtro);
            var base64 = Convert.ToBase64String(bytes);
            await JS.InvokeVoidAsync("downloadFile", "transacciones-ach.csv", base64);
        });
    }

    protected async Task AbrirDetalle(TransaccionDto item)
    {
        await ExecuteAsync(async () =>
        {
            OrdenSeleccionada = await TransaccionesService.ObtenerOrdenAsync(item.NumeroAch);
        });
    }

    protected void CerrarDetalle()
    {
        OrdenSeleccionada = null;
    }

    private async Task ExecuteAsync(Func<Task> action)
    {
        try
        {
            Loading = true;
            ErrorMessage = string.Empty;
            await action();
        }
        catch (HttpRequestException)
        {
            ErrorMessage = "No fue posible consultar las transacciones.";
        }
        finally
        {
            Loading = false;
        }
    }
}
```

Para una aplicación con muchas consultas, considera cancelar la solicitud anterior con `CancellationTokenSource` antes de iniciar una nueva búsqueda.

---

## 9. Modelo del detalle de orden

```csharp
public sealed class OrdenAchDetalleDto
{
    public string NumeroAch { get; set; } = string.Empty;
    public List<MensajeAchDto> Mensajes { get; set; } = [];
    public Dictionary<string, string> DatosGenerales { get; set; } = new();
    public Dictionary<string, string> Originante { get; set; } = new();
    public Dictionary<string, string> Destinatario { get; set; } = new();
}

public sealed class MensajeAchDto
{
    public string NumeroAch { get; set; } = string.Empty;
    public DateTime Inicio { get; set; }
    public DateTime Fin { get; set; }
    public string Originante { get; set; } = string.Empty;
    public string Destinatario { get; set; } = string.Empty;
    public string XmlOrigen { get; set; } = string.Empty;
    public string XmlDestino { get; set; } = string.Empty;
}
```

### Datos generales sugeridos

El bloque puede contener entre 13 y 15 campos:

```text
Número ACH
Cámara
Fecha cámara
Importe
Moneda
Estado
Error
Tipo de ACH
ID QR
Glosa
Inicio procesamiento
Fin procesamiento
Código de servicio
Código de respuesta
Etapa
```

### Originante

```text
Originante
Sub-originante
Número de orden originante
Número de intentos originante
Máximo de intentos a originante
Tipo de cuenta
Titular
CI/NIT
Origen de fondos
Cuenta origen
Ciudad origen
```

### Destinatario

```text
Destinatario
Sub-destinatario
Número de orden destinatario
Número de intentos destinatario
Máximo de intentos a destinatario
Tipo de cuenta
Titular
CI/NIT
Destino de fondos
Cuenta destino
Ciudad destino
```

Los valores de cuentas, documentos y titulares son datos sensibles. Deben mostrarse solo a usuarios autorizados y, si la política del banco lo exige, parcialmente enmascarados.

---

## 10. Modal de detalle de orden

```razor
@if (Orden is not null)
{
    <div class="modal-backdrop" @onclick="OnClose">
        <section class="order-modal" role="dialog" aria-modal="true"
                 aria-labelledby="order-modal-title"
                 @onclick:stopPropagation="true">
            <header class="modal-header">
                <div>
                    <h2 id="order-modal-title">Detalle de Orden ACH</h2>
                    <p>@Orden.NumeroAch</p>
                </div>
                <button class="close-button" @onclick="OnClose">Cerrar</button>
            </header>

            <div class="modal-content">
                <h3>Mensajes relacionados</h3>
                <table class="messages-table">
                    <thead>
                        <tr>
                            <th>Número ACH</th>
                            <th>Inicio</th>
                            <th>Fin</th>
                            <th>Originante</th>
                            <th>Destinatario</th>
                            <th>XML</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach (var mensaje in Orden.Mensajes)
                        {
                            <tr>
                                <td>@mensaje.NumeroAch</td>
                                <td>@mensaje.Inicio</td>
                                <td>@mensaje.Fin</td>
                                <td>@mensaje.Originante</td>
                                <td>@mensaje.Destinatario</td>
                                <td>
                                    <button @onclick="() => MostrarXml(mensaje.XmlOrigen)">XML origen</button>
                                    <button @onclick="() => MostrarXml(mensaje.XmlDestino)">XML destino</button>
                                </td>
                            </tr>
                        }
                    </tbody>
                </table>

                <div class="info-grid">
                    <InfoBlock Title="Datos generales" Data="@Orden.DatosGenerales" />
                    <InfoBlock Title="Originante" Data="@Orden.Originante" />
                    <InfoBlock Title="Destinatario" Data="@Orden.Destinatario" />
                </div>

                @if (!string.IsNullOrWhiteSpace(XmlSeleccionado))
                {
                    <XmlViewer Xml="@XmlSeleccionado" OnClose="CerrarXml" />
                }
            </div>

            <footer class="modal-footer">
                <button @onclick="OnClose">Cerrar</button>
                <a href="/transacciones/orden?ach=@Uri.EscapeDataString(Orden.NumeroAch)">
                    Abrir página completa
                </a>
            </footer>
        </section>
    </div>
}

@code {
    [Parameter, EditorRequired] public OrdenAchDetalleDto Orden { get; set; } = new();
    [Parameter] public EventCallback OnClose { get; set; }
    private string XmlSeleccionado { get; set; } = string.Empty;

    private void MostrarXml(string xml) => XmlSeleccionado = xml;
    private void CerrarXml() => XmlSeleccionado = string.Empty;
}
```

El modal debe tener scroll vertical, ancho adaptable y cerrar con botón, clic fuera y tecla Escape. Para accesibilidad, conserva el foco dentro del modal cuando esté abierto.

---

## 11. Visor XML

```razor
@if (!string.IsNullOrWhiteSpace(Xml))
{
    <section class="xml-viewer" aria-labelledby="xml-title">
        <div class="xml-header">
            <h3 id="xml-title">XML del mensaje</h3>
            <button @onclick="OnClose">Cerrar XML</button>
        </div>
        <pre><code>@Xml</code></pre>
    </section>
}

@code {
    [Parameter] public string Xml { get; set; } = string.Empty;
    [Parameter] public EventCallback OnClose { get; set; }
}
```

Nunca uses `MarkupString` para mostrar XML recibido desde una fuente externa. Renderízalo como texto para evitar inyección de HTML o scripts.

Si se desea formatear XML en el servidor:

```csharp
public static string FormatearXml(string xml)
{
    var document = XDocument.Parse(xml, LoadOptions.PreserveWhitespace);
    return document.ToString();
}
```

Captura errores de XML inválido y muestra el contenido sin romper el detalle.

---

## 12. API sugerida

```http
GET /api/transacciones?page=1&pageSize=20
GET /api/transacciones?fecha=2026-08-26&ciclo=CIC-01&numeroAch=1426
GET /api/transacciones/{id}
GET /api/transacciones/ordenes/{numeroAch}
GET /api/transacciones/export
```

La API debe:

1. Validar formato y longitud de los filtros.
2. Aplicar autorización por rol y participante.
3. Usar consultas parametrizadas.
4. Paginar antes de serializar.
5. Registrar auditoría de consultas sensibles.
6. Evitar devolver secretos o credenciales en el XML.
7. Limitar el tamaño máximo del XML.
8. Aplicar rate limiting a exportaciones.

La exportación debe recibir los filtros por query string o POST seguro y recalcular los datos en servidor. No debe confiar únicamente en la lista filtrada del navegador.

---

## 13. Descarga CSV

En `wwwroot/js/download.js`:

```javascript
window.downloadFile = (fileName, base64) => {
  const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
  const blob = new Blob([bytes], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
};
```

Carga el script en `index.html` o `_Host.cshtml` según el tipo de Blazor. Genera el CSV desde backend para grandes volúmenes y escapa comillas, saltos de línea y separadores.

---

## 14. Seguridad y auditoría

- Proteger la ruta con `[Authorize(Policy = "AchTransactions.Read")]`.
- Proteger detalle y XML con una política más restrictiva si contienen datos personales.
- Registrar usuario, fecha, número ACH consultado y acción realizada.
- No escribir XML, cuentas o documentos completos en logs.
- Enmascarar cuenta, CI/NIT y titular según rol.
- Usar HTTPS y tokens/sesiones seguras.
- Aplicar timeout y cancelación a llamadas HTTP.
- Validar que el usuario tenga acceso al participante consultado.
- Evitar guardar filtros o datos operativos sensibles en `localStorage`.

Ejemplo de autorización:

```razor
@attribute [Authorize(Policy = "AchTransactions.Read")]
```

---

## 15. Estilos BCP sugeridos

```css
:root {
    --navy: #001b41;
    --blue: #0061bd;
    --orange: #ff6600;
    --surface: #ffffff;
    --background: #f5f7fa;
    --border: #d9e2f2;
}

.operations-table thead,
.messages-table thead {
    background: linear-gradient(90deg, var(--navy), var(--blue));
    color: var(--surface);
}

.operations-table th,
.operations-table td,
.messages-table th,
.messages-table td {
    padding: .75rem 1rem;
    white-space: nowrap;
}

.table-responsive {
    overflow-x: auto;
}

.order-modal {
    width: min(94vw, 1200px);
    max-height: 92vh;
    overflow-y: auto;
    background: var(--surface);
    border-radius: 1rem;
}

.modal-backdrop {
    position: fixed;
    inset: 0;
    z-index: 1000;
    display: grid;
    place-items: center;
    padding: 1rem;
    background: rgb(0 0 0 / 60%);
}

.xml-viewer pre {
    max-height: 28rem;
    overflow: auto;
    padding: 1rem;
    border-radius: .5rem;
    background: #0f172a;
    color: #e2e8f0;
    white-space: pre-wrap;
}
```

Mantén la tabla con scroll horizontal en pantallas pequeñas. No reduzcas el tamaño del texto hasta impedir la lectura de columnas operativas.

---

## 16. Checklist de pruebas

### Listado

- [ ] La ruta `/transacciones` carga sin errores.
- [ ] Se muestran las 13 columnas de la captura.
- [ ] El número ACH es visible y navegable.
- [ ] La tabla conserva scroll horizontal.
- [ ] Los estados ACEP, PEND, RECH y ERR tienen estilos diferenciados.

### Filtros

- [ ] El checkbox global habilita y deshabilita todos los campos.
- [ ] Buscar sin filtros devuelve el listado general.
- [ ] Buscar con fecha aplica la fecha correcta.
- [ ] Buscar con ciclo filtra por ciclo.
- [ ] Buscar con número de orden filtra correctamente.
- [ ] Buscar con ACH filtra correctamente.
- [ ] Exportar funciona sin activar filtros.
- [ ] Exportar funciona con filtros activos.

### Detalle

- [ ] El número ACH abre `/transacciones/orden`.
- [ ] El botón de acción abre el modal.
- [ ] El modal muestra mensajes relacionados.
- [ ] Datos generales contiene entre 13 y 15 campos.
- [ ] Originante y Destinatario muestran sus datos respectivos.
- [ ] Se puede abrir XML de origen y destino.
- [ ] El XML se muestra como texto seguro.
- [ ] El modal se puede cerrar con botón y clic fuera.
- [ ] El enlace “Abrir página completa” conserva el número ACH.

### Seguridad

- [ ] La página exige autenticación.
- [ ] El detalle valida autorización por participante.
- [ ] Exportación queda auditada.
- [ ] No se exponen secretos en XML, logs o HTML.
- [ ] Los campos sensibles se enmascaran según rol.

---

## 17. Flujo funcional final

```text
Transacciones
    ├── Activar filtros (global)
    ├── Buscar
    ├── Exportar con/sin filtros
    ├── Click en Número ACH
    │     └── Página Detalle Orden ACH
    └── Click en Detalle de orden
          └── Modal Detalle Orden ACH
                ├── Mensajes relacionados
                ├── Datos generales
                ├── Originante
                ├── Destinatario
                ├── XML origen
                └── XML destino
```

La implementación debe conservar ambas alternativas: navegación a página completa para auditoría o enlaces compartibles, y modal para consultas rápidas del operador.
