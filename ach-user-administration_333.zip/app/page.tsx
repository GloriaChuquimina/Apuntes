'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Eye, X, Edit2, Trash2, Search, Home, Users, Briefcase, Users2, BarChart3, ArrowLeftRight, LockKeyhole, MessagesSquare, LogOut, Menu, ChevronDown, UserX, AlertTriangle } from 'lucide-react';

interface Usuario {
  id: string;
  usuario: string;
  keyName: string;
  email: string;
  celular: string;
  numeroDocumento: string;
  estado: string;
  usuarioCreador: string;
  usuarioModificador: string;
  fechaCreacion: string;
  fechaModificacion: string;
}

const usuarios: Usuario[] = [
  {
    id: '1',
    usuario: 'SOL_888',
    keyName: '1097',
    email: 'sandrat54@gmail.com',
    celular: '77288254',
    numeroDocumento: '6900889',
    estado: 'Habilitado',
    usuarioCreador: 'BC3467',
    usuarioModificador: 'BC3467',
    fechaCreacion: '2024-01-15',
    fechaModificacion: '2024-02-20',
  },
  {
    id: '2',
    usuario: 'SOL_999',
    keyName: '1097',
    email: 'pbravo@gmail.com',
    celular: '77268028',
    numeroDocumento: '8402596',
    estado: 'Habilitado',
    usuarioCreador: 'BC3467',
    usuarioModificador: 'BC3467',
    fechaCreacion: '2024-01-10',
    fechaModificacion: '2024-02-18',
  },
  {
    id: '3',
    usuario: 'SOL_111',
    keyName: '1097',
    email: 'vherrera@bcp.com.bo',
    celular: '71570493',
    numeroDocumento: '8301293',
    estado: 'Habilitado',
    usuarioCreador: 'BC2414',
    usuarioModificador: 'BC2414',
    fechaCreacion: '2024-01-05',
    fechaModificacion: '2024-02-15',
  },
  {
    id: '4',
    usuario: 'BCP666',
    keyName: '6666',
    email: 'dsantander@gmail.com',
    celular: '77288027',
    numeroDocumento: '85749632',
    estado: 'Habilitado',
    usuarioCreador: 'BC3467',
    usuarioModificador: 'BC3467',
    fechaCreacion: '2024-01-20',
    fechaModificacion: '2024-02-22',
  },
  {
    id: '5',
    usuario: 'BCP123',
    keyName: '1097',
    email: 'snina@gmail.com',
    celular: '71570493',
    numeroDocumento: '8301292',
    estado: 'Habilitado',
    usuarioCreador: 'BC3467',
    usuarioModificador: 'BC3467',
    fechaCreacion: '2024-01-12',
    fechaModificacion: '2024-02-19',
  },
];

export default function Page() {
  const [selectedUser, setSelectedUser] = useState<Usuario | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDisableModalOpen, setIsDisableModalOpen] = useState(false);
  const [isNewUserModalOpen, setIsNewUserModalOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const pathname = usePathname();

  const openModal = (usuario: Usuario) => {
    setSelectedUser(usuario);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedUser(null), 300);
  };

  const openDisableModal = (usuario: Usuario) => {
    setSelectedUser(usuario);
    setIsModalOpen(false);
    setIsDisableModalOpen(true);
  };

  const closeDisableModal = () => {
    setIsDisableModalOpen(false);
    setTimeout(() => setSelectedUser(null), 300);
  };

  const confirmDisable = () => {
    setIsDisableModalOpen(false);
    setTimeout(() => setSelectedUser(null), 300);
  };

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  const menuItems = [
    { icon: Home, label: 'Inicio', href: '/' },
    { icon: Users, label: 'Usuarios', href: '/' },
    { icon: Briefcase, label: 'Límites', href: '/limites' },
    { icon: Users2, label: 'Participantes', href: '/participantes' },
    { icon: BarChart3, label: 'Liquidación', href: '/liquidacion' },
    { icon: ArrowLeftRight, label: 'Transacciones', href: '/transacciones' },
    { icon: LockKeyhole, label: 'Cierre de Cámara', href: '/cierre-camara' },
    { icon: MessagesSquare, label: 'Mensajes ACH', href: '/mensajes' },
  ];

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: '#F5F7FA' }}>
      <aside
        className={`fixed left-0 top-0 h-full transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-20'
        } z-40`}
        style={{ backgroundColor: '#001B41' }}
      >
        {/* Logo */}
        <div className="p-6 border-b" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
          <Link href="/">
            <div className="flex items-center justify-center h-10 rounded-lg cursor-pointer" style={{ backgroundColor: '#FF6600' }}>
              <span className="text-white font-bold text-lg">BCP</span>
            </div>
          </Link>
        </div>

        {/* Menu Items */}
        <nav className="mt-8 max-h-[calc(100vh-180px)] space-y-2 overflow-y-auto px-3">
          {menuItems.map((item, idx) => (
            <Link
              key={idx}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive(item.href)
                  ? 'text-white'
                  : 'text-gray-300 hover:text-white'
              }`}
              style={
                isActive(item.href)
                  ? { backgroundColor: '#FF6600' }
                  : { backgroundColor: 'transparent' }
              }
            >
              <item.icon size={20} />
              {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
            </Link>
          ))}
        </nav>

        {/* Logout */}
        <div className="absolute bottom-6 left-3 right-3">
          <button
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-300 hover:text-white transition-all"
            style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}
          >
            <LogOut size={20} />
            {sidebarOpen && <span className="text-sm font-medium">Salir</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        {/* Top Header */}
        <div
          className="border-b px-8 py-4 flex justify-between items-center"
          style={{ backgroundColor: '#FFFFFF', borderColor: '#E5E7EB' }}
        >
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:rounded-lg transition-colors"
            style={{ color: '#001B41' }}
          >
            <Menu size={24} />
          </button>
          <div className="text-sm text-gray-600 flex items-center gap-1">
            BCP-ACH <ChevronDown size={16} />
          </div>
        </div>

        {/* Content Area */}
        <div className="p-8">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-2" style={{ color: '#001B41' }}>
                Administración de Usuarios
              </h1>
              <p className="text-gray-600 text-lg">Gestiona accesos, roles y estado de las cuentas</p>
            </div>

            {/* Search and Actions Bar */}
            <div className="mb-6 flex gap-4 items-center">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-3" size={20} style={{ color: '#6B7280' }} />
                <input
                  type="text"
                  placeholder="Buscar por nombre, matrícula o correo..."
                  className="w-full pl-12 pr-4 py-3 border rounded-lg bg-white text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:border-transparent transition-all"
                  style={{ borderColor: '#E5E7EB' } as any}
                />
              </div>
              <button
                onClick={() => setIsNewUserModalOpen(true)}
                className="px-6 py-3 text-white rounded-lg hover:opacity-90 transition-all duration-200 font-semibold shadow-md hover:shadow-lg"
                style={{ backgroundColor: '#2D9C3E' }}
              >
                + Nuevo Usuario
              </button>
            </div>

            {/* Stats */}
            <div className="mb-6 flex justify-between items-center">
              <div className="text-sm text-gray-600">
                Mostrando <span className="font-semibold" style={{ color: '#001B41' }}>{usuarios.length}</span> de{' '}
                <span className="font-semibold" style={{ color: '#001B41' }}>16</span> registros
              </div>
            </div>

            {/* Table */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden border" style={{ borderColor: '#E5E7EB' }}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ background: 'linear-gradient(to right, #001B41, #0061BD)' }}>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Usuario</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Email</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Celular</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Estado</th>
                      <th className="px-6 py-4 text-center text-sm font-bold text-white">Acción</th>
                    </tr>
                  </thead>
                  <tbody style={{ borderColor: '#E5E7EB' }} className="divide-y">
                    {usuarios.map((usuario) => (
                      <tr
                        key={usuario.id}
                        className="transition-colors duration-200 hover:opacity-80"
                        style={{ backgroundColor: '#FFFFFF' }}
                      >
                        <td className="px-6 py-4">
                          <span className="text-sm font-semibold" style={{ color: '#001B41' }}>
                            {usuario.usuario}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm" style={{ color: '#6B7280' }}>
                            {usuario.email}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm" style={{ color: '#6B7280' }}>
                            {usuario.celular}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold"
                            style={{ backgroundColor: '#D1FAE5', color: '#2D9C3E' }}
                          >
                            {usuario.estado}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => openModal(usuario)}
                            className="inline-flex items-center justify-center p-2 rounded-lg text-white hover:opacity-90 transition-all duration-200 hover:shadow-lg transform hover:scale-110"
                            style={{ backgroundColor: '#FF6600' }}
                            title="Ver detalle"
                          >
                            <Eye size={18} />
                          </button>
                          <button
                            onClick={() => openDisableModal(usuario)}
                            className="inline-flex items-center justify-center p-2 ml-2 rounded-lg text-white hover:opacity-90 transition-all duration-200 hover:shadow-lg"
                            style={{ backgroundColor: '#DC2626' }}
                            title="Deshabilitar usuario"
                            aria-label={`Deshabilitar ${usuario.usuario}`}
                          >
                            <UserX size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div
          className={`fixed inset-0 bg-black transition-opacity duration-300 z-40 ${
            isModalOpen ? 'opacity-50' : 'opacity-0'
          }`}
          onClick={closeModal}
        />
      )}

      {/* Modal */}
      {isModalOpen && selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className={`bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all duration-300 ${
              isModalOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div
              className="px-8 py-6 flex justify-between items-center rounded-t-2xl"
              style={{ background: 'linear-gradient(to right, #001B41, #0061BD)' }}
            >
              <div>
                <h2 className="text-2xl font-bold text-white">Detalle del Usuario</h2>
                <p className="text-blue-100 text-sm mt-1">Información completa de {selectedUser.usuario}</p>
              </div>
              <button
                onClick={closeModal}
                className="p-2 hover:opacity-80 rounded-lg transition-colors"
              >
                <X size={24} className="text-white" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="px-8 py-8">
              {/* Datos Principales */}
              <div className="grid grid-cols-2 gap-8 mb-8">
                {/* Columna Izquierda */}
                <div className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Usuario
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.usuario}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Key Name
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.keyName}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Email
                    </label>
                    <p className="text-base font-semibold break-all" style={{ color: '#001B41' }}>
                      {selectedUser.email}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Celular
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.celular}
                    </p>
                  </div>
                </div>

                {/* Columna Derecha */}
                <div className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Número de Documento
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.numeroDocumento}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Estado
                    </label>
                    <span
                      className="inline-flex items-center px-4 py-2 rounded-full text-sm font-bold"
                      style={{ backgroundColor: '#D1FAE5', color: '#2D9C3E' }}
                    >
                      ✓ {selectedUser.estado}
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Usuario Creador
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.usuarioCreador}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Usuario Modificador
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.usuarioModificador}
                    </p>
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="my-8 border-t-2" style={{ borderColor: '#E5E7EB' }} />

              {/* Información de Auditoría */}
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: '#FF6600' }}>
                  Información de Auditoría
                </h3>
                <div className="grid grid-cols-2 gap-8 p-6 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Fecha de Creación
                    </label>
                    <p className="text-base font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.fechaCreacion}
                    </p>
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Fecha de Modificación
                    </label>
                    <p className="text-base font-semibold" style={{ color: '#001B41' }}>
                      {selectedUser.fechaModificacion}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div
              className="px-8 py-4 flex justify-end gap-3 rounded-b-2xl border-t"
              style={{ backgroundColor: '#F5F7FA', borderColor: '#E5E7EB' }}
            >
              <button
                onClick={closeModal}
                className="px-6 py-2 font-semibold rounded-lg transition-colors"
                style={{ color: '#001B41', backgroundColor: 'transparent', border: '1px solid #E5E7EB' }}
              >
                Cerrar
              </button>
              <button
                className="px-6 py-2 text-white font-semibold rounded-lg transition-all duration-200 flex items-center gap-2 hover:shadow-lg hover:opacity-90"
                style={{ backgroundColor: '#0061BD' }}
              >
                <Edit2 size={18} />
                Editar
              </button>
              <button
                onClick={() => selectedUser && openDisableModal(selectedUser)}
                className="px-6 py-2 text-white font-semibold rounded-lg transition-all duration-200 flex items-center gap-2 hover:shadow-lg hover:opacity-90"
                style={{ backgroundColor: '#DC2626' }}
              >
                <UserX size={18} />
                Deshabilitar
              </button>
            </div>
          </div>
        </div>
      )}

      {isNewUserModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4" onClick={() => setIsNewUserModalOpen(false)}>
          <div className="w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="new-user-title">
            <div className="flex items-center justify-between px-6 py-5" style={{ backgroundColor: '#001B41' }}>
              <div><h2 id="new-user-title" className="text-xl font-bold text-white">Registrar nuevo usuario</h2><p className="text-sm text-blue-100">Completa los datos de acceso</p></div>
              <button onClick={() => setIsNewUserModalOpen(false)} className="text-white/80 hover:text-white" aria-label="Cerrar registro"><X size={20} /></button>
            </div>
            <div className="space-y-4 px-6 py-6">
              <label className="block text-sm font-semibold" style={{ color: '#001B41' }}>Usuario<input className="mt-2 w-full rounded-lg border p-3 text-sm text-gray-900 outline-none focus:ring-2" style={{ borderColor: '#E5E7EB' }} placeholder="Ej. SOL_888" /></label>
              <label className="block text-sm font-semibold" style={{ color: '#001B41' }}>Contraseña<input type="password" className="mt-2 w-full rounded-lg border p-3 text-sm text-gray-900 outline-none focus:ring-2" style={{ borderColor: '#E5E7EB' }} placeholder="Ingresa una contraseña segura" aria-describedby="password-rules" />
                <span id="password-rules" className="mt-2 block rounded-lg p-3 text-xs leading-5" style={{ color: '#475569', backgroundColor: '#F5F7FA' }}><strong style={{ color: '#001B41' }}>La contraseña debe incluir:</strong><br />• Mayúsculas y minúsculas<br />• Al menos un carácter especial, por ejemplo: <code className="font-semibold">. _ @</code></span>
              </label>
            </div>
            <div className="flex justify-end gap-3 border-t px-6 py-4" style={{ backgroundColor: '#F5F7FA', borderColor: '#E5E7EB' }}><button onClick={() => setIsNewUserModalOpen(false)} className="rounded-lg border px-5 py-2 font-semibold" style={{ borderColor: '#E5E7EB', color: '#001B41' }}>Cancelar</button><button onClick={() => setIsNewUserModalOpen(false)} className="rounded-lg px-5 py-2 font-semibold text-white" style={{ backgroundColor: '#2D9C3E' }}>Registrar usuario</button></div>
          </div>
        </div>
      )}

      {isDisableModalOpen && selectedUser && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4" onClick={closeDisableModal}>
          <div className="w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-2xl" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="disable-user-title">
            <div className="flex items-center gap-3 px-6 py-5" style={{ backgroundColor: '#FFF4ED' }}>
              <div className="rounded-full p-2" style={{ backgroundColor: '#FFEDD5', color: '#DC2626' }}><AlertTriangle size={22} /></div>
              <div><h2 id="disable-user-title" className="text-xl font-bold" style={{ color: '#001B41' }}>Deshabilitar usuario</h2><p className="text-sm text-gray-600">Confirmación de seguridad</p></div>
            </div>
            <div className="space-y-4 px-6 py-6">
              <p className="text-sm leading-6 text-gray-700">¿Deseas deshabilitar al usuario <strong style={{ color: '#001B41' }}>{selectedUser.usuario}</strong>?</p>
              <div className="rounded-lg border p-4 text-sm" style={{ borderColor: '#FED7AA', backgroundColor: '#FFFBEB' }}>
                El usuario perderá el acceso al sistema. Esta acción quedará registrada en la auditoría y podrá revertirse posteriormente.
              </div>
              <label className="block text-xs font-bold uppercase tracking-wider" style={{ color: '#6B7280' }}>Motivo (opcional)<textarea className="mt-2 min-h-20 w-full resize-none rounded-lg border p-3 text-sm text-gray-900 outline-none focus:ring-2" style={{ borderColor: '#E5E7EB' }} placeholder="Ingresa el motivo de la deshabilitación" /></label>
            </div>
            <div className="flex justify-end gap-3 border-t px-6 py-4" style={{ backgroundColor: '#F5F7FA', borderColor: '#E5E7EB' }}>
              <button onClick={closeDisableModal} className="rounded-lg border px-5 py-2 font-semibold" style={{ borderColor: '#E5E7EB', color: '#001B41' }}>Cancelar</button>
              <button onClick={confirmDisable} className="flex items-center gap-2 rounded-lg px-5 py-2 font-semibold text-white hover:opacity-90" style={{ backgroundColor: '#DC2626' }}><UserX size={17} /> Confirmar deshabilitación</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
