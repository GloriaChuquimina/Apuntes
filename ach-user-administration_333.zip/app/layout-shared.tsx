'use client';

import { ReactNode, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Users, Briefcase, Users2, BarChart3, ArrowLeftRight, LockKeyhole, MessagesSquare, LogOut, Menu } from 'lucide-react';

export function SharedLayout({ children }: { children: ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const pathname = usePathname();

  const menuItems = [
    { icon: Home, label: 'Inicio', href: '/' },
    { icon: Users, label: 'Usuarios', href: '/' },
    { icon: Briefcase, label: 'Límites', href: '/limites' },
    { icon: Users2, label: 'Participantes', href: '/participantes' },
    { icon: BarChart3, label: 'Liquidación', href: '/liquidacion' },
    { icon: ArrowLeftRight, label: 'Transacciones', href: '/transacciones' },
    { icon: LockKeyhole, label: 'Cierre de Cámara', href: '/cierre-camara' },
    { icon: MessagesSquare, label: 'Mensajes ACH', href: '/mensajes' },
  ];

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: '#F5F7FA' }}>
      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 h-full transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-20'
        } z-40`}
        style={{ backgroundColor: '#001B41' }}
      >
        {/* Logo */}
        <div className="p-6 border-b" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
          <Link href="/">
            <div className="flex items-center justify-center h-10 rounded-lg" style={{ backgroundColor: '#FF6600' }}>
              <span className="text-white font-bold text-lg">BCP</span>
            </div>
          </Link>
        </div>

        {/* Menu Items */}
        <nav className="mt-8 max-h-[calc(100vh-180px)] space-y-2 overflow-y-auto px-3">
          {menuItems.map((item, idx) => (
            <Link
              key={idx}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive(item.href)
                  ? 'text-white'
                  : 'text-gray-300 hover:text-white'
              }`}
              style={
                isActive(item.href)
                  ? { backgroundColor: '#FF6600' }
                  : { backgroundColor: 'transparent' }
              }
            >
              <item.icon size={20} />
              {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
            </Link>
          ))}
        </nav>

        {/* Logout */}
        <div className="absolute bottom-6 left-3 right-3">
          <button
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-300 hover:text-white transition-all"
            style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}
          >
            <LogOut size={20} />
            {sidebarOpen && <span className="text-sm font-medium">Salir</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main
        className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}
      >
        {/* Top Header */}
        <div
          className="border-b px-8 py-4 flex justify-between items-center"
          style={{ backgroundColor: '#FFFFFF', borderColor: '#E5E7EB' }}
        >
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:rounded-lg transition-colors"
            style={{ color: '#001B41' }}
          >
            <Menu size={24} />
          </button>
          <div className="text-sm text-gray-600">BCP-ACH</div>
        </div>

        {/* Content Area */}
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
