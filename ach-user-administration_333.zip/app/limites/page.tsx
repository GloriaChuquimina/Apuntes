'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Eye, X, Edit2, Trash2, Search, Home, Users, Briefcase, Users2, BarChart3, ArrowLeftRight, LockKeyhole, MessagesSquare, LogOut, Menu, ChevronDown, AlertCircle } from 'lucide-react';

interface Limite {
  id: string;
  codigo: string;
  participante: string;
  moneda: string;
  montoLimite: number;
  balanceUsado: number;
  porcentajeUso: number;
  estado: string;
  usuarioCreador: string;
  fechaCreacion: string;
  fechaModificacion: string;
}

const limites: Limite[] = [
  {
    id: '1',
    codigo: '1001',
    participante: 'BANCO SOL',
    moneda: 'USD',
    montoLimite: 1000000,
    balanceUsado: 850000,
    porcentajeUso: 85,
    estado: 'Activo',
    usuarioCreador: 'BC3467',
    fechaCreacion: '2024-01-15',
    fechaModificacion: '2024-03-10',
  },
  {
    id: '2',
    codigo: '1005',
    participante: 'BANCO DE CRÉDITO',
    moneda: 'BOB',
    montoLimite: 5000000,
    balanceUsado: 2300000,
    porcentajeUso: 46,
    estado: 'Activo',
    usuarioCreador: 'BC3467',
    fechaCreacion: '2024-01-20',
    fechaModificacion: '2024-03-08',
  },
  {
    id: '3',
    codigo: '1009',
    participante: 'BANCO MERCANTIL',
    moneda: 'USD',
    montoLimite: 750000,
    balanceUsado: 120000,
    porcentajeUso: 16,
    estado: 'Activo',
    usuarioCreador: 'BC2414',
    fechaCreacion: '2024-02-01',
    fechaModificacion: '2024-03-09',
  },
  {
    id: '4',
    codigo: '1033',
    participante: 'BANCO UNIÓN',
    moneda: 'BOB',
    montoLimite: 3000000,
    balanceUsado: 2850000,
    porcentajeUso: 95,
    estado: 'Advertencia',
    usuarioCreador: 'BC3467',
    fechaCreacion: '2024-01-10',
    fechaModificacion: '2024-03-11',
  },
  {
    id: '5',
    codigo: '1056',
    participante: 'CAJA DE AHORROS',
    moneda: 'BOB',
    montoLimite: 500000,
    balanceUsado: 499500,
    porcentajeUso: 99,
    estado: 'Crítico',
    usuarioCreador: 'BC2414',
    fechaCreacion: '2024-02-05',
    fechaModificacion: '2024-03-12',
  },
];

function Sidebar({ sidebarOpen, setSidebarOpen }: { sidebarOpen: boolean; setSidebarOpen: (open: boolean) => void }) {
  const pathname = usePathname();
  
  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };
  
  const menuItems = [
    { icon: Home, label: 'Inicio', href: '/' },
    { icon: Users, label: 'Usuarios', href: '/' },
    { icon: Briefcase, label: 'Límites', href: '/limites' },
    { icon: Users2, label: 'Participantes', href: '/participantes' },
    { icon: BarChart3, label: 'Liquidación', href: '/liquidacion' },
    { icon: ArrowLeftRight, label: 'Transacciones', href: '/transacciones' },
    { icon: LockKeyhole, label: 'Cierre de Cámara', href: '/cierre-camara' },
    { icon: MessagesSquare, label: 'Mensajes ACH', href: '/mensajes' },
  ];

  return (
    <aside
      className={`fixed left-0 top-0 h-full transition-all duration-300 ${sidebarOpen ? 'w-64' : 'w-20'} z-40`}
      style={{ backgroundColor: '#001B41' }}
    >
      <div className="p-6 border-b" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
        <div className="flex items-center justify-center h-10 rounded-lg" style={{ backgroundColor: '#FF6600' }}>
          <span className="text-white font-bold text-lg">BCP</span>
        </div>
      </div>

      <nav className="mt-8 max-h-[calc(100vh-180px)] space-y-2 overflow-y-auto px-3">
        {menuItems.map((item, idx) => (
          <Link
            key={idx}
            href={item.href}
            className="flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200"
            style={
              isActive(item.href)
                ? { backgroundColor: '#FF6600', color: 'white' }
                : { color: '#d1d5db' }
            }
          >
            <item.icon size={20} />
            {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
          </Link>
        ))}
      </nav>

      <div className="absolute bottom-6 left-3 right-3">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all" style={{ backgroundColor: 'rgba(255,255,255,0.05)', color: '#d1d5db' }}>
          <LogOut size={20} />
          {sidebarOpen && <span className="text-sm font-medium">Salir</span>}
        </button>
      </div>
    </aside>
  );
}

export default function LimitesPage() {
  const [selectedLimite, setSelectedLimite] = useState<Limite | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const openModal = (limite: Limite) => {
    setSelectedLimite(limite);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedLimite(null), 300);
  };

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'Activo':
        return { bg: '#D1FAE5', color: '#2D9C3E' };
      case 'Advertencia':
        return { bg: '#FEF3C7', color: '#D97706' };
      case 'Crítico':
        return { bg: '#FEE2E2', color: '#DC2626' };
      default:
        return { bg: '#F3F4F6', color: '#6B7280' };
    }
  };

  const getProgressColor = (porcentaje: number) => {
    if (porcentaje >= 90) return '#DC2626';
    if (porcentaje >= 75) return '#D97706';
    return '#2D9C3E';
  };

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: '#F5F7FA' }}>
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <div className="border-b px-8 py-4 flex justify-between items-center bg-white" style={{ borderColor: '#E5E7EB' }}>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:rounded-lg transition-colors" style={{ color: '#001B41' }}>
            <Menu size={24} />
          </button>
          <div className="text-sm text-gray-600">
            BCP-ACH <ChevronDown size={16} className="inline ml-2" />
          </div>
        </div>

        <div className="p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-2" style={{ color: '#001B41' }}>
                Control de Límites
              </h1>
              <p className="text-gray-600 text-lg">Monitoreo de límites en operaciones ACH</p>
            </div>

            <div className="mb-6 flex gap-4 items-center">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-3" size={20} style={{ color: '#6B7280' }} />
                <input
                  type="text"
                  placeholder="Buscar por código, participante o moneda..."
                  className="w-full pl-12 pr-4 py-3 border rounded-lg bg-white text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:border-transparent transition-all"
                  style={{ borderColor: '#E5E7EB', '--tw-ring-color': '#0061BD' } as any}
                />
              </div>
              <button className="px-6 py-3 text-white rounded-lg hover:opacity-90 transition-all duration-200 font-semibold shadow-md hover:shadow-lg" style={{ backgroundColor: '#2D9C3E' }}>
                + Nuevo
              </button>
            </div>

            <div className="mb-6 flex justify-between items-center">
              <div className="text-sm text-gray-600">
                Mostrando <span className="font-semibold" style={{ color: '#001B41' }}>{limites.length}</span> de{' '}
                <span className="font-semibold" style={{ color: '#001B41' }}>5</span> registros
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden border" style={{ borderColor: '#E5E7EB' }}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ background: 'linear-gradient(to right, #001B41, #0061BD)' }}>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Código</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Participante</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Moneda</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Límite</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Uso %</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Estado</th>
                      <th className="px-6 py-4 text-center text-sm font-bold text-white">Acción</th>
                    </tr>
                  </thead>
                  <tbody style={{ borderColor: '#E5E7EB' }} className="divide-y">
                    {limites.map((limite) => (
                      <tr key={limite.id} className="transition-colors duration-200 hover:opacity-80" style={{ backgroundColor: '#FFFFFF' }}>
                        <td className="px-6 py-4">
                          <span className="text-sm font-semibold" style={{ color: '#001B41' }}>
                            {limite.codigo}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm" style={{ color: '#6B7280' }}>
                            {limite.participante}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm font-semibold" style={{ color: '#0061BD' }}>
                            {limite.moneda}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm" style={{ color: '#6B7280' }}>
                            {limite.montoLimite.toLocaleString('es-ES')}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div className="w-12 h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full transition-all"
                                style={{
                                  width: `${limite.porcentajeUso}%`,
                                  backgroundColor: getProgressColor(limite.porcentajeUso),
                                }}
                              />
                            </div>
                            <span className="text-xs font-semibold" style={{ color: getProgressColor(limite.porcentajeUso) }}>
                              {limite.porcentajeUso}%
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold"
                            style={getEstadoBadge(limite.estado)}
                          >
                            {limite.estado}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => openModal(limite)}
                            className="inline-flex items-center justify-center p-2 rounded-lg text-white hover:opacity-90 transition-all duration-200 hover:shadow-lg transform hover:scale-110"
                            style={{ backgroundColor: '#FF6600' }}
                          >
                            <Eye size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main>

      {isModalOpen && (
        <div
          className={`fixed inset-0 bg-black transition-opacity duration-300 z-40 ${isModalOpen ? 'opacity-50' : 'opacity-0'}`}
          onClick={closeModal}
        />
      )}

      {isModalOpen && selectedLimite && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className={`bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all duration-300 ${
              isModalOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-8 py-6 flex justify-between items-center rounded-t-2xl" style={{ background: 'linear-gradient(to right, #001B41, #0061BD)' }}>
              <div>
                <h2 className="text-2xl font-bold text-white">Detalle del Límite</h2>
                <p className="text-blue-100 text-sm mt-1">Información del participante {selectedLimite.participante}</p>
              </div>
              <button onClick={closeModal} className="p-2 hover:opacity-80 rounded-lg transition-colors">
                <X size={24} className="text-white" />
              </button>
            </div>

            <div className="px-8 py-8">
              <div className="grid grid-cols-2 gap-8 mb-8">
                <div className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Código
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedLimite.codigo}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Participante
                    </label>
                    <p className="text-base font-semibold" style={{ color: '#001B41' }}>
                      {selectedLimite.participante}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Moneda
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#0061BD' }}>
                      {selectedLimite.moneda}
                    </p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Monto Límite
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedLimite.montoLimite.toLocaleString('es-ES')} {selectedLimite.moneda}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Balance Usado
                    </label>
                    <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                      {selectedLimite.balanceUsado.toLocaleString('es-ES')} {selectedLimite.moneda}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                      Porcentaje Uso
                    </label>
                    <div className="flex items-center gap-3">
                      <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${selectedLimite.porcentajeUso}%`,
                            backgroundColor: getProgressColor(selectedLimite.porcentajeUso),
                          }}
                        />
                      </div>
                      <span className="text-lg font-semibold" style={{ color: getProgressColor(selectedLimite.porcentajeUso) }}>
                        {selectedLimite.porcentajeUso}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="my-8 border-t-2" style={{ borderColor: '#E5E7EB' }} />

              <div className="grid grid-cols-3 gap-4 p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                    Estado
                  </label>
                  <span
                    className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold"
                    style={getEstadoBadge(selectedLimite.estado)}
                  >
                    {selectedLimite.estado}
                  </span>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                    Usuario Creador
                  </label>
                  <p className="text-sm font-semibold" style={{ color: '#001B41' }}>
                    {selectedLimite.usuarioCreador}
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                    Fecha Modificación
                  </label>
                  <p className="text-sm font-semibold" style={{ color: '#001B41' }}>
                    {selectedLimite.fechaModificacion}
                  </p>
                </div>
              </div>
            </div>

            <div className="px-8 py-4 flex justify-end gap-3 rounded-b-2xl border-t" style={{ backgroundColor: '#F5F7FA', borderColor: '#E5E7EB' }}>
              <button
                onClick={closeModal}
                className="px-6 py-2 font-semibold rounded-lg transition-colors"
                style={{ color: '#001B41', backgroundColor: 'transparent', border: '1px solid #E5E7EB' }}
              >
                Cerrar
              </button>
              <button
                className="px-6 py-2 text-white font-semibold rounded-lg transition-all duration-200 flex items-center gap-2 hover:shadow-lg hover:opacity-90"
                style={{ backgroundColor: '#0061BD' }}
              >
                <Edit2 size={18} />
                Editar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
