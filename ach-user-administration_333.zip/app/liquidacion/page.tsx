'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Eye, X, Edit2, Trash2, Search, Home, Users, Briefcase, Users2, BarChart3, ArrowLeftRight, LockKeyhole, MessagesSquare, LogOut, Menu, ChevronDown, TrendingUp, Clock } from 'lucide-react';

interface Ciclo {
  id: string;
  numero: string;
  fechaInicio: string;
  fechaFin: string;
  totalOperaciones: number;
  montoTotal: number;
  moneda: string;
  estado: string;
  usuarioCreador: string;
  fechaCreacion: string;
  participantesInvolucrados: number;
  transferenciasSalida: number;
  transferenciasEntrada: number;
  neteo: number;
}

const ciclos: Ciclo[] = [
  {
    id: '1',
    numero: '2024-03-001',
    fechaInicio: '2024-03-01',
    fechaFin: '2024-03-15',
    totalOperaciones: 3250,
    montoTotal: 125500000,
    moneda: 'BOB',
    estado: 'Liquidado',
    usuarioCreador: 'BC3467',
    fechaCreacion: '2024-03-15 15:30:00',
    participantesInvolucrados: 8,
    transferenciasSalida: 1625,
    transferenciasEntrada: 1625,
    neteo: 250000,
  },
  {
    id: '2',
    numero: '2024-03-002',
    fechaInicio: '2024-03-16',
    fechaFin: '2024-03-31',
    totalOperaciones: 4120,
    montoTotal: 185750000,
    moneda: 'BOB',
    estado: 'Liquidado',
    usuarioCreador: 'BC3467',
    fechaCreacion: '2024-03-31 18:45:00',
    participantesInvolucrados: 9,
    transferenciasSalida: 2060,
    transferenciasEntrada: 2060,
    neteo: 320000,
  },
  {
    id: '3',
    numero: '2024-04-001',
    fechaInicio: '2024-04-01',
    fechaFin: '2024-04-15',
    totalOperaciones: 3890,
    montoTotal: 156230000,
    moneda: 'BOB',
    estado: 'En Proceso',
    usuarioCreador: 'BC2414',
    fechaCreacion: '2024-04-15 16:20:00',
    participantesInvolucrados: 8,
    transferenciasSalida: 1945,
    transferenciasEntrada: 1945,
    neteo: 280000,
  },
  {
    id: '4',
    numero: '2024-04-002',
    fechaInicio: '2024-04-16',
    fechaFin: '2024-04-30',
    totalOperaciones: 2540,
    montoTotal: 98500000,
    moneda: 'BOB',
    estado: 'Pendiente',
    usuarioCreador: 'BC3467',
    fechaCreacion: '2024-04-20 10:15:00',
    participantesInvolucrados: 7,
    transferenciasSalida: 1270,
    transferenciasEntrada: 1270,
    neteo: 150000,
  },
];

function Sidebar({ sidebarOpen, setSidebarOpen }: { sidebarOpen: boolean; setSidebarOpen: (open: boolean) => void }) {
  const pathname = usePathname();
  
  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };
  
  const menuItems = [
    { icon: Home, label: 'Inicio', href: '/' },
    { icon: Users, label: 'Usuarios', href: '/' },
    { icon: Briefcase, label: 'Límites', href: '/limites' },
    { icon: Users2, label: 'Participantes', href: '/participantes' },
    { icon: BarChart3, label: 'Liquidación', href: '/liquidacion' },
  { icon: ArrowLeftRight, label: 'Transacciones', href: '/transacciones' },
  { icon: LockKeyhole, label: 'Cierre de Cámara', href: '/cierre-camara' },
  { icon: MessagesSquare, label: 'Mensajes ACH', href: '/mensajes' },
  ];

  return (
    <aside
      className={`fixed left-0 top-0 h-full transition-all duration-300 ${sidebarOpen ? 'w-64' : 'w-20'} z-40`}
      style={{ backgroundColor: '#001B41' }}
    >
      <div className="p-6 border-b" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
        <Link href="/">
          <div className="flex items-center justify-center h-10 rounded-lg cursor-pointer" style={{ backgroundColor: '#FF6600' }}>
            <span className="text-white font-bold text-lg">BCP</span>
          </div>
        </Link>
      </div>

      <nav className="mt-8 max-h-[calc(100vh-180px)] space-y-2 overflow-y-auto px-3">
        {menuItems.map((item, idx) => (
          <Link
            key={idx}
            href={item.href}
            className="flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200"
            style={
              isActive(item.href)
                ? { backgroundColor: '#FF6600', color: 'white' }
                : { color: '#d1d5db' }
            }
          >
            <item.icon size={20} />
            {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
          </Link>
        ))}
      </nav>

      <div className="absolute bottom-6 left-3 right-3">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all" style={{ backgroundColor: 'rgba(255,255,255,0.05)', color: '#d1d5db' }}>
          <LogOut size={20} />
          {sidebarOpen && <span className="text-sm font-medium">Salir</span>}
        </button>
      </div>
    </aside>
  );
}

export default function LiquidacionPage() {
  const [selectedCiclo, setSelectedCiclo] = useState<Ciclo | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const openModal = (ciclo: Ciclo) => {
    setSelectedCiclo(ciclo);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedCiclo(null), 300);
  };

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'Liquidado':
        return { bg: '#D1FAE5', color: '#2D9C3E' };
      case 'En Proceso':
        return { bg: '#FEF3C7', color: '#D97706' };
      case 'Pendiente':
        return { bg: '#F3F4F6', color: '#6B7280' };
      default:
        return { bg: '#F3F4F6', color: '#6B7280' };
    }
  };

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: '#F5F7FA' }}>
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <div className="border-b px-8 py-4 flex justify-between items-center bg-white" style={{ borderColor: '#E5E7EB' }}>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:rounded-lg transition-colors" style={{ color: '#001B41' }}>
            <Menu size={24} />
          </button>
          <div className="text-sm text-gray-600">
            BCP-ACH <ChevronDown size={16} className="inline ml-2" />
          </div>
        </div>

        <div className="p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-2" style={{ color: '#001B41' }}>
                Liquidación por Ciclo
              </h1>
              <p className="text-gray-600 text-lg">Gestión de ciclos de liquidación del sistema ACH</p>
            </div>

            {/* Resumen de Ciclos */}
            <div className="grid grid-cols-4 gap-4 mb-8">
              <div className="bg-white p-6 rounded-lg shadow" style={{ borderLeft: '4px solid #FF6600' }}>
                <p className="text-sm text-gray-600 mb-2">Ciclos Liquidados</p>
                <p className="text-3xl font-bold" style={{ color: '#001B41' }}>2</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow" style={{ borderLeft: '4px solid #D97706' }}>
                <p className="text-sm text-gray-600 mb-2">En Proceso</p>
                <p className="text-3xl font-bold" style={{ color: '#001B41' }}>1</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow" style={{ borderLeft: '4px solid #6B7280' }}>
                <p className="text-sm text-gray-600 mb-2">Pendientes</p>
                <p className="text-3xl font-bold" style={{ color: '#001B41' }}>1</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow" style={{ borderLeft: '4px solid #0061BD' }}>
                <p className="text-sm text-gray-600 mb-2">Total Operaciones</p>
                <p className="text-3xl font-bold" style={{ color: '#001B41' }}>13,800</p>
              </div>
            </div>

            <div className="mb-6 flex gap-4 items-center">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-3" size={20} style={{ color: '#6B7280' }} />
                <input
                  type="text"
                  placeholder="Buscar por número de ciclo o fecha..."
                  className="w-full pl-12 pr-4 py-3 border rounded-lg bg-white text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:border-transparent transition-all"
                  style={{ borderColor: '#E5E7EB', '--tw-ring-color': '#0061BD' } as any}
                />
              </div>
              <button className="px-6 py-3 text-white rounded-lg hover:opacity-90 transition-all duration-200 font-semibold shadow-md hover:shadow-lg" style={{ backgroundColor: '#2D9C3E' }}>
                + Nuevo Ciclo
              </button>
            </div>

            <div className="mb-6 flex justify-between items-center">
              <div className="text-sm text-gray-600">
                Mostrando <span className="font-semibold" style={{ color: '#001B41' }}>{ciclos.length}</span> de{' '}
                <span className="font-semibold" style={{ color: '#001B41' }}>4</span> registros
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden border" style={{ borderColor: '#E5E7EB' }}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ background: 'linear-gradient(to right, #001B41, #0061BD)' }}>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Ciclo</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Período</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Operaciones</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Monto Total</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Participantes</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-white">Estado</th>
                      <th className="px-6 py-4 text-center text-sm font-bold text-white">Acción</th>
                    </tr>
                  </thead>
                  <tbody style={{ borderColor: '#E5E7EB' }} className="divide-y">
                    {ciclos.map((ciclo) => (
                      <tr key={ciclo.id} className="transition-colors duration-200 hover:opacity-80" style={{ backgroundColor: '#FFFFFF' }}>
                        <td className="px-6 py-4">
                          <span className="text-sm font-semibold" style={{ color: '#001B41' }}>
                            {ciclo.numero}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <Clock size={16} style={{ color: '#6B7280' }} />
                            <span className="text-sm" style={{ color: '#6B7280' }}>
                              {ciclo.fechaInicio} a {ciclo.fechaFin}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <TrendingUp size={16} style={{ color: '#0061BD' }} />
                            <span className="text-sm font-semibold" style={{ color: '#0061BD' }}>
                              {ciclo.totalOperaciones.toLocaleString('es-ES')}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm font-semibold" style={{ color: '#001B41' }}>
                            {(ciclo.montoTotal / 1000000).toFixed(2)}M {ciclo.moneda}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold"
                            style={{ backgroundColor: '#E0E7FF', color: '#3730A3' }}
                          >
                            {ciclo.participantesInvolucrados}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold" style={getEstadoBadge(ciclo.estado)}>
                            {ciclo.estado}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => openModal(ciclo)}
                            className="inline-flex items-center justify-center p-2 rounded-lg text-white hover:opacity-90 transition-all duration-200 hover:shadow-lg transform hover:scale-110"
                            style={{ backgroundColor: '#FF6600' }}
                          >
                            <Eye size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main>

      {isModalOpen && (
        <div
          className={`fixed inset-0 bg-black transition-opacity duration-300 z-40 ${isModalOpen ? 'opacity-50' : 'opacity-0'}`}
          onClick={closeModal}
        />
      )}

      {isModalOpen && selectedCiclo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className={`bg-white rounded-2xl shadow-2xl w-full max-w-3xl transform transition-all duration-300 ${
              isModalOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-8 py-6 flex justify-between items-center rounded-t-2xl" style={{ background: 'linear-gradient(to right, #001B41, #0061BD)' }}>
              <div>
                <h2 className="text-2xl font-bold text-white">Detalle del Ciclo</h2>
                <p className="text-blue-100 text-sm mt-1">Ciclo {selectedCiclo.numero}</p>
              </div>
              <button onClick={closeModal} className="p-2 hover:opacity-80 rounded-lg transition-colors">
                <X size={24} className="text-white" />
              </button>
            </div>

            <div className="px-8 py-8">
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                    Número de Ciclo
                  </label>
                  <p className="text-lg font-semibold" style={{ color: '#001B41' }}>
                    {selectedCiclo.numero}
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                    Período
                  </label>
                  <p className="text-sm font-semibold" style={{ color: '#001B41' }}>
                    {selectedCiclo.fechaInicio} a {selectedCiclo.fechaFin}
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#FF6600' }}>
                    Estado
                  </label>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold" style={getEstadoBadge(selectedCiclo.estado)}>
                    {selectedCiclo.estado}
                  </span>
                </div>
              </div>

              <div className="my-8 border-t-2" style={{ borderColor: '#E5E7EB' }} />

              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: '#FF6600' }}>
                  Estadísticas de Operaciones
                </h3>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Total de Operaciones
                    </label>
                    <p className="text-2xl font-bold" style={{ color: '#0061BD' }}>
                      {selectedCiclo.totalOperaciones.toLocaleString('es-ES')}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Salidas
                    </label>
                    <p className="text-2xl font-bold" style={{ color: '#2D9C3E' }}>
                      {selectedCiclo.transferenciasSalida.toLocaleString('es-ES')}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Entradas
                    </label>
                    <p className="text-2xl font-bold" style={{ color: '#D97706' }}>
                      {selectedCiclo.transferenciasEntrada.toLocaleString('es-ES')}
                    </p>
                  </div>
                </div>
              </div>

              <div className="my-8 border-t-2" style={{ borderColor: '#E5E7EB' }} />

              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: '#FF6600' }}>
                  Información Financiera
                </h3>
                <div className="grid grid-cols-3 gap-6">
                  <div className="p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Monto Total
                    </label>
                    <p className="text-lg font-bold" style={{ color: '#001B41' }}>
                      {(selectedCiclo.montoTotal / 1000000).toFixed(2)}M {selectedCiclo.moneda}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Neteo
                    </label>
                    <p className="text-lg font-bold" style={{ color: '#0061BD' }}>
                      {selectedCiclo.neteo.toLocaleString('es-ES')} {selectedCiclo.moneda}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                    <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                      Participantes
                    </label>
                    <p className="text-lg font-bold" style={{ color: '#FF6600' }}>
                      {selectedCiclo.participantesInvolucrados}
                    </p>
                  </div>
                </div>
              </div>

              <div className="my-8 border-t-2" style={{ borderColor: '#E5E7EB' }} />

              <div className="grid grid-cols-2 gap-4 p-4 rounded-lg" style={{ backgroundColor: '#F5F7FA' }}>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                    Creado por
                  </label>
                  <p className="text-sm font-semibold" style={{ color: '#001B41' }}>
                    {selectedCiclo.usuarioCreador}
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#6B7280' }}>
                    Fecha de Creación
                  </label>
                  <p className="text-sm font-semibold" style={{ color: '#001B41' }}>
                    {selectedCiclo.fechaCreacion}
                  </p>
                </div>
              </div>
            </div>

            <div className="px-8 py-4 flex justify-end gap-3 rounded-b-2xl border-t" style={{ backgroundColor: '#F5F7FA', borderColor: '#E5E7EB' }}>
              <button
                onClick={closeModal}
                className="px-6 py-2 font-semibold rounded-lg transition-colors"
                style={{ color: '#001B41', backgroundColor: 'transparent', border: '1px solid #E5E7EB' }}
              >
                Cerrar
              </button>
              <button
                className="px-6 py-2 text-white font-semibold rounded-lg transition-all duration-200 flex items-center gap-2 hover:shadow-lg hover:opacity-90"
                style={{ backgroundColor: '#0061BD' }}
              >
                <Edit2 size={18} />
                Editar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
