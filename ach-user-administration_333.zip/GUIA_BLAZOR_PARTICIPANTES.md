# Guía completa de Participantes en Blazor

Esta guía documenta cómo implementar la pantalla de Participantes del portal BCP-ACH en Blazor, incluyendo listado, alta, edición, activación, desactivación y registro de certificados digitales.

## 1. Alcance funcional

La pantalla debe permitir:

- Consultar participantes con paginación y búsqueda.
- Registrar un participante QR.
- Editar la configuración de un participante existente.
- Consultar el detalle completo.
- Activar o desactivar un participante mediante confirmación.
- Registrar o actualizar su certificado digital.
- Mostrar auditoría y estado operativo.

La lista debe mostrar únicamente información operativa esencial. Los valores técnicos y de seguridad deben aparecer en el detalle o en formularios protegidos.

## 2. Estructura recomendada

```text
Pages/
└── Participantes/
    ├── Index.razor
    ├── ParticipanteForm.razor
    ├── ParticipanteDetalle.razor
    ├── ActivarDesactivarModal.razor
    └── CertificadoModal.razor

Models/
├── Participante.cs
├── ParticipanteDtos.cs
└── Certificado.cs

Services/
└── ParticipanteService.cs

wwwroot/css/
└── participantes.css
```

Se recomienda separar los modales en componentes para evitar que `Index.razor` se convierta en un componente difícil de mantener.

## 3. Modelo de dominio

### Models/Participante.cs

```csharp
namespace AchPortal.Models;

public sealed class Participante
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string BaseUrl { get; set; } = string.Empty;
    public string Endpoint { get; set; } = string.Empty;
    public string NameSpace { get; set; } = string.Empty;
    public string Method { get; set; } = "receptorExpress";
    public int CodeCamera { get; set; }
    public string NameCamera { get; set; } = string.Empty;
    public string KeyName { get; set; } = string.Empty;
    public string InputName { get; set; } = string.Empty;
    public string OutputName { get; set; } = string.Empty;
    public string Enrollment { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Telefono { get; set; } = string.Empty;
    public string Ciudad { get; set; } = string.Empty;
    public EstadoParticipante Estado { get; set; }
    public string UsuarioCreador { get; set; } = string.Empty;
    public DateTime FechaCreacion { get; set; }
    public string? UsuarioModificador { get; set; }
    public DateTime? FechaModificacion { get; set; }
    public int CuentasActivas { get; set; }
    public int OperacionesMes { get; set; }
    public Certificado? Certificado { get; set; }
}

public enum EstadoParticipante
{
    Activo,
    Suspendido,
    Inactivo
}
```

### Models/Certificado.cs

```csharp
namespace AchPortal.Models;

public sealed class Certificado
{
    public string KeyName { get; set; } = string.Empty;
    public string ThumbPrint { get; set; } = string.Empty;
    public string Serial { get; set; } = string.Empty;
    public string PublicToken { get; set; } = string.Empty;
    public string Enrollment { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public DateTime? FechaRegistro { get; set; }
    public string? UsuarioRegistro { get; set; }
}
```

## 4. DTOs para la API

No conviene enviar directamente el modelo de dominio desde la interfaz. Usa DTOs específicos por operación.

### Alta y actualización

```csharp
public sealed class CreateParticipanteRequest
{
    [Required, StringLength(20)]
    public string Name { get; set; } = string.Empty;

    [Required, Url]
    public string BaseUrl { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string Endpoint { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string NameSpace { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Method { get; set; } = "receptorExpress";

    [Range(1, int.MaxValue)]
    public int CodeCamera { get; set; }

    [Required, StringLength(50)]
    public string NameCamera { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string KeyName { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string InputName { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string OutputName { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Enrollment { get; set; } = string.Empty;
}

public sealed class UpdateParticipanteRequest : CreateParticipanteRequest
{
    [Range(1, int.MaxValue)]
    public int Id { get; set; }
}
```

El JSON esperado para alta es:

```json
{
  "Name": "1005",
  "BaseUrl": "https://bcp.com.bo.cer",
  "Endpoint": "pruebas/qr",
  "NameSpace": "bcp.com",
  "Method": "receptorExpress",
  "CodeCamera": 1426001,
  "NameCamera": "ACCL",
  "KeyName": "1056",
  "InputName": "pruebaEntrada",
  "OutputName": "pruebaSalida",
  "Enrollment": "BC2414"
}
```

El JSON esperado para actualización agrega el identificador:

```json
{
  "Id": 3,
  "Name": "BANCO DE CREDITO",
  "BaseUrl": "https://bcp.com.bo.cer",
  "Endpoint": "pruebas/qr",
  "NameSpace": "bcp.com",
  "Method": "receptorExpress",
  "CodeCamera": 1426001,
  "NameCamera": "ACCL",
  "KeyName": "1056",
  "InputName": "pruebaEntrada",
  "OutputName": "pruebaSalida",
  "Enrollment": "BC2414"
}
```

### Activar y desactivar

```csharp
public sealed class ParticipantStatusRequest
{
    [Range(1, int.MaxValue)]
    public int Id { get; set; }

    [Required, StringLength(50)]
    public string Enrollment { get; set; } = string.Empty;
}
```

JSON:

```json
{
  "Id": 7,
  "Enrollment": "BC2414"
}
```

### Registro de certificado

```csharp
public sealed class RegisterCertificateRequest
{
    [Required, StringLength(50)]
    public string KeyName { get; set; } = string.Empty;

    [Required, StringLength(200)]
    public string ThumbPrint { get; set; } = string.Empty;

    [Required, StringLength(200)]
    public string Serial { get; set; } = string.Empty;

    [Required, StringLength(1000)]
    public string PublicToken { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Enrollment { get; set; } = string.Empty;

    [Required, StringLength(1000)]
    public string Subject { get; set; } = string.Empty;
}
```

## 5. Servicio HTTP

### Services/ParticipanteService.cs

```csharp
using System.Net.Http.Json;
using AchPortal.Models;

public sealed class ParticipanteService
{
    private readonly HttpClient _http;

    public ParticipanteService(HttpClient http)
    {
        _http = http;
    }

    public async Task<IReadOnlyList<Participante>> GetAsync(
        string? search = null,
        CancellationToken cancellationToken = default)
    {
        var url = string.IsNullOrWhiteSpace(search)
            ? "api/Participant"
            : $"api/Participant?search={Uri.EscapeDataString(search)}";

        return await _http.GetFromJsonAsync<List<Participante>>(url, cancellationToken)
            ?? [];
    }

    public async Task CreateAsync(
        CreateParticipanteRequest request,
        CancellationToken cancellationToken = default)
    {
        using var response = await _http.PostAsJsonAsync(
            "api/Participant/CreateParticipant", request, cancellationToken);

        response.EnsureSuccessStatusCode();
    }

    public async Task UpdateAsync(
        UpdateParticipanteRequest request,
        CancellationToken cancellationToken = default)
    {
        using var response = await _http.PutAsJsonAsync(
            "api/Participant/UpdateParticipant", request, cancellationToken);

        response.EnsureSuccessStatusCode();
    }

    public async Task EnableAsync(
        ParticipantStatusRequest request,
        CancellationToken cancellationToken = default)
    {
        using var response = await _http.PostAsJsonAsync(
            "api/Participant/EnableParticipant", request, cancellationToken);

        response.EnsureSuccessStatusCode();
    }

    public async Task DisableAsync(
        ParticipantStatusRequest request,
        CancellationToken cancellationToken = default)
    {
        using var response = await _http.PostAsJsonAsync(
            "api/Participant/DisableParticipant", request, cancellationToken);

        response.EnsureSuccessStatusCode();
    }

    public async Task RegisterCertificateAsync(
        RegisterCertificateRequest request,
        CancellationToken cancellationToken = default)
    {
        using var response = await _http.PostAsJsonAsync(
            "api/Participant/RegisterCertified", request, cancellationToken);

        response.EnsureSuccessStatusCode();
    }
}
```

Registro en `Program.cs`:

```csharp
builder.Services.AddHttpClient<ParticipanteService>(client =>
{
    client.BaseAddress = new Uri(builder.HostEnvironment.BaseAddress);
});
```

En Blazor Server usa la URL de la API configurada en `appsettings.json`. No coloques URLs, tokens ni certificados directamente en componentes Razor.

## 6. Pantalla principal

### Pages/Participantes/Index.razor

```razor
@page "/participantes"
@using AchPortal.Models
@using AchPortal.Services
@inject ParticipanteService ParticipanteService

<PageTitle>Gestión de Participantes</PageTitle>

<div class="page-shell">
    <div class="page-heading">
        <div>
            <h1>Gestión de Participantes</h1>
            <p>Administra instituciones, integración QR y certificados digitales.</p>
        </div>
        <button class="btn btn-success" @onclick="AbrirNuevo">
            <span aria-hidden="true">+</span>
            Nuevo participante
        </button>
    </div>

    <div class="toolbar">
        <label class="search-box">
            <span class="sr-only">Buscar participantes</span>
            <input @bind="busqueda" @bind:event="oninput"
                   placeholder="Buscar por código, nombre o ciudad..." />
        </label>
    </div>

    @if (cargando)
    {
        <div class="loading-state" role="status">Cargando participantes...</div>
    }
    else
    {
        <div class="table-card">
            <table class="data-table">
                <caption class="sr-only">Participantes registrados</caption>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Participante</th>
                        <th>Ciudad</th>
                        <th>Estado</th>
                        <th>Certificado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach (var participante in ParticipantesFiltrados)
                    {
                        <tr>
                            <td class="strong">@participante.Codigo</td>
                            <td>
                                <div class="strong">@participante.Nombre</div>
                                <div class="muted">@participante.Email</div>
                            </td>
                            <td>@participante.Ciudad</td>
                            <td>
                                <span class="status @EstadoCss(participante.Estado)">
                                    @participante.Estado
                                </span>
                            </td>
                            <td>
                                @(participante.Certificado is null
                                    ? "Sin certificado"
                                    : "Registrado")
                            </td>
                            <td>
                                <div class="action-group">
                                    <button class="btn-icon btn-blue"
                                            title="Ver detalle"
                                            aria-label="Ver detalle de @participante.Nombre"
                                            @onclick="() => AbrirDetalle(participante)">
                                        Ver
                                    </button>
                                    <button class="btn-icon btn-orange"
                                            title="Editar participante"
                                            aria-label="Editar @participante.Nombre"
                                            @onclick="() => AbrirEdicion(participante)">
                                        Editar
                                    </button>
                                    <button class="btn-icon btn-dark"
                                            title="Activar o desactivar"
                                            aria-label="Cambiar estado de @participante.Nombre"
                                            @onclick="() => AbrirCambioEstado(participante)">
                                        Estado
                                    </button>
                                </div>
                            </td>
                        </tr>
                    }
                </tbody>
            </table>
        </div>
    }
</div>

@if (modal == ModalTipo.Formulario)
{
    <ParticipanteForm Participante="participanteSeleccionado"
                      Guardado="GuardarParticipante"
                      Cerrado="CerrarModal" />
}

@if (modal == ModalTipo.Detalle && participanteSeleccionado is not null)
{
    <ParticipanteDetalle Participante="participanteSeleccionado"
                         Editar="AbrirEdicion"
                         Certificado="AbrirCertificado"
                         Cerrado="CerrarModal" />
}

@if (modal == ModalTipo.Estado && participanteSeleccionado is not null)
{
    <ActivarDesactivarModal Participante="participanteSeleccionado"
                            Confirmado="CambiarEstado"
                            Cerrado="CerrarModal" />
}

@if (modal == ModalTipo.Certificado && participanteSeleccionado is not null)
{
    <CertificadoModal Participante="participanteSeleccionado"
                      Guardado="GuardarCertificado"
                      Cerrado="CerrarModal" />
}
```

## 7. Código de la página

```razor
@code {
    private List<Participante> participantes = [];
    private Participante? participanteSeleccionado;
    private string busqueda = string.Empty;
    private bool cargando = true;
    private ModalTipo? modal;

    private IEnumerable<Participante> ParticipantesFiltrados =>
        participantes.Where(x =>
            $"{x.Codigo} {x.Nombre} {x.Ciudad}"
                .Contains(busqueda, StringComparison.OrdinalIgnoreCase));

    protected override async Task OnInitializedAsync()
    {
        participantes = (await ParticipanteService.GetAsync()).ToList();
        cargando = false;
    }

    private void AbrirNuevo()
    {
        participanteSeleccionado = null;
        modal = ModalTipo.Formulario;
    }

    private void AbrirDetalle(Participante participante)
    {
        participanteSeleccionado = participante;
        modal = ModalTipo.Detalle;
    }

    private void AbrirEdicion(Participante participante)
    {
        participanteSeleccionado = participante;
        modal = ModalTipo.Formulario;
    }

    private void AbrirCambioEstado(Participante participante)
    {
        participanteSeleccionado = participante;
        modal = ModalTipo.Estado;
    }

    private void AbrirCertificado(Participante participante)
    {
        participanteSeleccionado = participante;
        modal = ModalTipo.Certificado;
    }

    private async Task GuardarParticipante(ParticipanteFormResult result)
    {
        if (result.Id is null)
        {
            await ParticipanteService.CreateAsync(result.CreateRequest);
        }
        else
        {
            await ParticipanteService.UpdateAsync(result.UpdateRequest!);
        }

        participantes = (await ParticipanteService.GetAsync(busqueda)).ToList();
        CerrarModal();
    }

    private async Task CambiarEstado()
    {
        if (participanteSeleccionado is null)
            return;

        var request = new ParticipantStatusRequest
        {
            Id = participanteSeleccionado.Id,
            Enrollment = participanteSeleccionado.Enrollment
        };

        if (participanteSeleccionado.Estado == EstadoParticipante.Activo)
            await ParticipanteService.DisableAsync(request);
        else
            await ParticipanteService.EnableAsync(request);

        participantes = (await ParticipanteService.GetAsync(busqueda)).ToList();
        CerrarModal();
    }

    private async Task GuardarCertificado(RegisterCertificateRequest request)
    {
        await ParticipanteService.RegisterCertificateAsync(request);
        participantes = (await ParticipanteService.GetAsync(busqueda)).ToList();
        CerrarModal();
    }

    private void CerrarModal()
    {
        modal = null;
        participanteSeleccionado = null;
    }

    private static string EstadoCss(EstadoParticipante estado) => estado switch
    {
        EstadoParticipante.Activo => "status-success",
        EstadoParticipante.Suspendido => "status-warning",
        _ => "status-neutral"
    };

    private enum ModalTipo
    {
        Formulario,
        Detalle,
        Estado,
        Certificado
    }
}
```

## 8. Modal de alta y edición

El mismo modal sirve para alta y actualización. Solo cambia el título y la operación ejecutada.

### ParticipanteForm.razor

```razor
@using System.ComponentModel.DataAnnotations
@using AchPortal.Models

<div class="modal-backdrop" @onclick="Cerrar">
    <section class="modal modal-xl" role="dialog" aria-modal="true"
             aria-labelledby="participante-form-title"
             @onclick:stopPropagation>
        <header class="modal-header modal-header-blue">
            <div>
                <h2 id="participante-form-title">
                    @(Participante is null ? "Nuevo participante" : "Editar participante")
                </h2>
                <p>Configuración de integración ACH / QR</p>
            </div>
            <button class="modal-close" @onclick="Cerrar" aria-label="Cerrar">×</button>
        </header>

        <EditForm Model="modelo" OnValidSubmit="Guardar">
            <DataAnnotationsValidator />
            <ValidationSummary class="validation-summary" />

            <div class="modal-body form-sections">
                <section>
                    <h3>Identificación y contacto</h3>
                    <div class="form-grid">
                        <div class="field">
                            <label for="codigo">Código</label>
                            <InputText id="codigo" @bind-Value="modelo.Codigo" />
                            <ValidationMessage For="@(() => modelo.Codigo)" />
                        </div>
                        <div class="field">
                            <label for="nombre">Nombre</label>
                            <InputText id="nombre" @bind-Value="modelo.Nombre" />
                            <ValidationMessage For="@(() => modelo.Nombre)" />
                        </div>
                        <div class="field">
                            <label for="email">Correo electrónico</label>
                            <InputText id="email" type="email" @bind-Value="modelo.Email" />
                        </div>
                        <div class="field">
                            <label for="telefono">Teléfono</label>
                            <InputText id="telefono" @bind-Value="modelo.Telefono" />
                        </div>
                        <div class="field">
                            <label for="ciudad">Ciudad</label>
                            <InputText id="ciudad" @bind-Value="modelo.Ciudad" />
                        </div>
                        <div class="field">
                            <label for="enrollment">Enrollment</label>
                            <InputText id="enrollment" @bind-Value="modelo.Enrollment" />
                            <ValidationMessage For="@(() => modelo.Enrollment)" />
                        </div>
                    </div>
                </section>

                <section>
                    <h3>Configuración técnica</h3>
                    <div class="form-grid">
                        <div class="field field-wide">
                            <label for="base-url">Base URL</label>
                            <InputText id="base-url" @bind-Value="modelo.BaseUrl" />
                        </div>
                        <div class="field">
                            <label for="endpoint">Endpoint</label>
                            <InputText id="endpoint" @bind-Value="modelo.Endpoint" />
                        </div>
                        <div class="field">
                            <label for="namespace">NameSpace</label>
                            <InputText id="namespace" @bind-Value="modelo.NameSpace" />
                        </div>
                        <div class="field">
                            <label for="method">Método</label>
                            <InputText id="method" @bind-Value="modelo.Method" />
                        </div>
                        <div class="field">
                            <label for="code-camera">CodeCamera</label>
                            <InputNumber id="code-camera" @bind-Value="modelo.CodeCamera" />
                        </div>
                        <div class="field">
                            <label for="name-camera">NameCamera</label>
                            <InputText id="name-camera" @bind-Value="modelo.NameCamera" />
                        </div>
                        <div class="field">
                            <label for="key-name">KeyName</label>
                            <InputText id="key-name" @bind-Value="modelo.KeyName" />
                        </div>
                        <div class="field">
                            <label for="input-name">InputName</label>
                            <InputText id="input-name" @bind-Value="modelo.InputName" />
                        </div>
                        <div class="field">
                            <label for="output-name">OutputName</label>
                            <InputText id="output-name" @bind-Value="modelo.OutputName" />
                        </div>
                    </div>
                </section>
            </div>

            <footer class="modal-footer">
                <button type="button" class="btn btn-secondary" @onclick="Cerrar">Cancelar</button>
                <button type="submit" class="btn btn-blue">Guardar participante</button>
            </footer>
        </EditForm>
    </section>
</div>
```

El modelo del formulario debe contener validaciones como `[Required]`, `[StringLength]`, `[Url]` y `[Range]`. La validación debe repetirse en el backend; la validación de Blazor no es un control de seguridad.

## 9. Modal de activación y desactivación

No cambies el estado directamente desde la tabla. Primero muestra una confirmación clara, informa el participante, el identificador y el enrollment, y registra la operación en auditoría.

```razor
<div class="modal-backdrop" @onclick="Cerrar">
    <section class="modal modal-sm" role="alertdialog" aria-modal="true"
             aria-labelledby="estado-title" @onclick:stopPropagation>
        <header class="modal-header modal-header-orange">
            <div>
                <h2 id="estado-title">
                    @(Participante.Estado == EstadoParticipante.Activo
                        ? "Desactivar participante"
                        : "Activar participante")
                </h2>
                <p>@Participante.Nombre · @Participante.Codigo</p>
            </div>
            <button class="modal-close" @onclick="Cerrar" aria-label="Cerrar">×</button>
        </header>

        <div class="modal-body">
            <div class="warning-box">
                Esta operación modifica el estado operativo del participante.
                Verifica que la solicitud esté autorizada antes de continuar.
            </div>
            <dl class="confirm-list">
                <div><dt>Participante</dt><dd>@Participante.Nombre</dd></div>
                <div><dt>Enrollment</dt><dd>@Participante.Enrollment</dd></div>
                <div><dt>Estado actual</dt><dd>@Participante.Estado</dd></div>
            </dl><se
        </div>

        <footer class="modal-footer">
            <button class="btn btn-secondary" @onclick="Cerrar">Cancelar</button>
            <button class="btn @(Participante.Estado == EstadoParticipante.Activo ? "btn-danger" : "btn-success")"
                    @onclick="Confirmar">
                @(Participante.Estado == EstadoParticipante.Activo
                    ? "Confirmar desactivación"
                    : "Confirmar activación")
            </button>
        </footer>
    </section>
</div>

@code {
    [Parameter, EditorRequired] public Participante Participante { get; set; } = null!;
    [Parameter, EditorRequired] public EventCallback Confirmado { get; set; }
    [Parameter, EditorRequired] public EventCallback Cerrado { get; set; }

    private Task Confirmar() => Confirmado.InvokeAsync();
    private Task Cerrar() => Cerrado.InvokeAsync();
}
```

## 10. Modal de certificado digital

El diseño se inspira en la ventana proporcionada: encabezado naranja, formulario técnico y sección de detalle. Por seguridad, el certificado no debe mostrarse en la tabla y el token no debe escribirse en logs.

```razor
<div class="modal-backdrop" @onclick="Cerrar">
    <section class="modal modal-xl" role="dialog" aria-modal="true"
             aria-labelledby="certificate-title" @onclick:stopPropagation>
        <header class="modal-header modal-header-orange">
            <div>
                <h2 id="certificate-title">Registro de certificado</h2>
                <p>@Participante.Nombre · POST /api/Participant/RegisterCertified</p>
            </div>
            <button class="modal-close" @onclick="Cerrar" aria-label="Cerrar">×</button>
        </header>

        <EditForm Model="modelo" OnValidSubmit="Guardar">
            <DataAnnotationsValidator />
            <div class="modal-body">
                <div class="security-box">
                    <strong>Credencial digital protegida</strong>
                    <p>Los datos se transmiten únicamente por HTTPS y no deben aparecer en logs.</p>
                </div>

                <div class="form-grid">
                    <div class="field">
                        <label for="certificate-key">KeyName</label>
                        <InputText id="certificate-key" @bind-Value="modelo.KeyName" />
                    </div>
                    <div class="field">
                        <label for="certificate-enrollment">Enrollment</label>
                        <InputText id="certificate-enrollment" @bind-Value="modelo.Enrollment" />
                    </div>
                    <div class="field field-wide">
                        <label for="thumbprint">ThumbPrint</label>
                        <InputText id="thumbprint" @bind-Value="modelo.ThumbPrint" />
                    </div>
                    <div class="field field-wide">
                        <label for="serial">Serial</label>
                        <InputText id="serial" @bind-Value="modelo.Serial" />
                    </div>
                    <div class="field field-wide">
                        <label for="subject">Asunto</label>
                        <InputText id="subject" @bind-Value="modelo.Subject" />
                    </div>
                    <div class="field field-wide">
                        <label for="public-token">Clave pública / PublicToken</label>
                        <InputTextArea id="public-token" @bind-Value="modelo.PublicToken" rows="5" />
                    </div>
                </div>
            </div>

            <footer class="modal-footer">
                <button type="button" class="btn btn-secondary" @onclick="Cerrar">Cancelar</button>
                <button type="submit" class="btn btn-orange">Registrar certificado</button>
            </footer>
        </EditForm>
    </section>
</div>
```

## 11. Modal de detalle

El detalle debe ser de solo lectura. Divide la información en bloques:

1. Identificación: código, nombre, ciudad y estado.
2. Integración: Base URL, endpoint, namespace y método.
3. Cámara QR: CodeCamera, NameCamera, KeyName, InputName y OutputName.
4. Certificado: estado registrado, serial y thumbprint parcialmente ocultos.
5. Auditoría: usuario creador, fecha de creación, usuario modificador y fecha de modificación.

Para ocultar valores sensibles:

```csharp
private static string Mask(string value, int visible = 6)
{
    if (string.IsNullOrWhiteSpace(value) || value.Length <= visible)
        return value;

    return $"{value[..visible]}••••••";
}
```

No uses `Mask` como sustituto de autorización. El backend debe decidir qué campos puede consultar cada rol.

## 12. CSS de la línea BCP

### wwwroot/css/participantes.css

```css
:root {
    --bcp-navy: #001B41;
    --bcp-orange: #FF6600;
    --bcp-blue: #0061BD;
    --bcp-green: #2D9C3E;
    --bcp-red: #DC2626;
    --bcp-bg: #F5F7FA;
    --bcp-border: #E5E7EB;
    --bcp-muted: #6B7280;
}

.page-shell {
    min-height: 100vh;
    padding: 32px;
    background: var(--bcp-bg);
}

.page-heading,
.toolbar,
.modal-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
}

.page-heading h1 {
    margin: 0;
    color: var(--bcp-navy);
    font-size: 32px;
}

.page-heading p {
    margin: 8px 0 0;
    color: var(--bcp-muted);
}

.table-card {
    overflow: auto;
    border: 1px solid var(--bcp-border);
    border-radius: 14px;
    background: white;
    box-shadow: 0 8px 22px rgba(0, 27, 65, .08);
}

.data-table {
    width: 100%;
    min-width: 980px;
    border-collapse: collapse;
}

.data-table th {
    padding: 15px 20px;
    color: white;
    background: linear-gradient(90deg, var(--bcp-navy), var(--bcp-blue));
    font-size: 12px;
    text-align: left;
    text-transform: uppercase;
}

.data-table td {
    padding: 15px 20px;
    border-bottom: 1px solid var(--bcp-border);
    color: #1F2937;
}

.data-table tr:hover {
    background: #EFF6FF;
}

.modal-backdrop {
    position: fixed;
    inset: 0;
    z-index: 100;
    display: grid;
    place-items: center;
    padding: 16px;
    background: rgba(0, 0, 0, .52);
}

.modal {
    width: min(100%, 640px);
    max-height: 92vh;
    overflow: auto;
    border-radius: 14px;
    background: white;
    box-shadow: 0 24px 80px rgba(0, 0, 0, .25);
}

.modal-xl { width: min(100%, 980px); }
.modal-sm { width: min(100%, 520px); }

.modal-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    padding: 22px 28px;
    color: white;
}

.modal-header-blue { background: linear-gradient(90deg, var(--bcp-navy), var(--bcp-blue)); }
.modal-header-orange { background: var(--bcp-orange); }
.modal-header h2 { margin: 0; font-size: 24px; }
.modal-header p { margin: 5px 0 0; opacity: .85; }
.modal-close { border: 0; color: white; background: transparent; font-size: 28px; cursor: pointer; }
.modal-body { padding: 28px; }
.modal-footer { justify-content: flex-end; padding: 16px 28px; border-top: 1px solid var(--bcp-border); background: var(--bcp-bg); }

.form-sections section + section { margin-top: 30px; padding-top: 24px; border-top: 1px solid var(--bcp-border); }
.form-sections h3 { margin: 0 0 16px; color: var(--bcp-orange); }
.form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
.field-wide { grid-column: span 2; }
.field label { display: block; margin-bottom: 7px; color: var(--bcp-navy); font-size: 12px; font-weight: 700; text-transform: uppercase; }
.field input, .field textarea, .field select { box-sizing: border-box; width: 100%; border: 1px solid #D8DEE8; border-radius: 8px; padding: 10px 12px; color: #1F2937; background: white; }
.field input:focus, .field textarea:focus { outline: 2px solid rgba(0, 97, 189, .25); border-color: var(--bcp-blue); }
.warning-box, .security-box { margin-bottom: 20px; border-radius: 10px; padding: 14px 16px; font-size: 14px; }
.warning-box { border: 1px solid #FED7AA; color: #9A3412; background: #FFF7ED; }
.security-box { border: 1px solid #BFDBFE; color: #1E3A8A; background: #EFF6FF; }

.btn { border: 0; border-radius: 8px; padding: 10px 18px; font-weight: 700; cursor: pointer; }
.btn-blue { color: white; background: var(--bcp-blue); }
.btn-orange { color: white; background: var(--bcp-orange); }
.btn-success { color: white; background: var(--bcp-green); }
.btn-danger { color: white; background: var(--bcp-red); }
.btn-secondary { border: 1px solid var(--bcp-border); color: var(--bcp-navy); background: white; }
.btn-icon { border: 0; border-radius: 7px; padding: 8px 10px; color: white; cursor: pointer; }
.btn-dark { background: var(--bcp-navy); }
.action-group { display: flex; gap: 7px; }
.muted { color: var(--bcp-muted); font-size: 12px; }
.strong { color: var(--bcp-navy); font-weight: 700; }

@media (max-width: 720px) {
    .page-shell { padding: 20px 14px; }
    .page-heading, .toolbar { align-items: stretch; flex-direction: column; }
    .form-grid { grid-template-columns: 1fr; }
    .field-wide { grid-column: auto; }
    .modal-header, .modal-body, .modal-footer { padding: 18px; }
    .modal-footer { align-items: stretch; flex-direction: column-reverse; }
    .modal-footer .btn { width: 100%; }
}
```

En `index.html` o `App.razor` agrega:

```html
<link href="css/participantes.css" rel="stylesheet" />
```

## 13. Registro en el contenedor de componentes

```csharp
builder.Services.AddScoped<ParticipanteService>();
```

Si el proyecto es Blazor WebAssembly, utiliza `AddHttpClient`. Si es Blazor Server, configura el `HttpClient` con la URL de tu API y no expongas secretos en el navegador.

## 14. Seguridad y buenas prácticas

### Autorización

Protege la página y cada operación:

```razor
@attribute [Authorize(Policy = "ParticipantesAdministrar")]
```

En el servidor valida nuevamente la política. No confíes en que ocultar un botón sea autorización.

### Reglas recomendadas

- HTTPS obligatorio en todos los ambientes salvo desarrollo local.
- Validación de DTOs en cliente y servidor.
- Protección antiforgery en endpoints mutables cuando aplique.
- No registrar `PublicToken`, certificados completos ni credenciales en logs.
- No guardar certificados en `localStorage`.
- No incluir secretos en `appsettings.json` del cliente.
- Usar roles separados para consultar, editar, activar y registrar certificados.
- Confirmar activación y desactivación con `alertdialog`.
- Registrar auditoría: usuario, fecha, IP o correlación de operación.
- Usar `CancellationToken` y manejar respuestas 401, 403, 409 y 500.
- Evitar mostrar Base URL interna si el usuario no tiene permiso técnico.
- Aplicar paginación en el servidor cuando la cantidad de participantes crezca.

## 15. Manejo de errores

```csharp
private string? error;
private bool guardando;

private async Task EjecutarOperacion(Func<Task> operation)
{
    error = null;
    guardando = true;

    try
    {
        await operation();
    }
    catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.Conflict)
    {
        error = "El participante ya existe o tiene una operación pendiente.";
    }
    catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.Forbidden)
    {
        error = "No tienes permisos para ejecutar esta operación.";
    }
    catch (HttpRequestException)
    {
        error = "No fue posible completar la operación. Intenta nuevamente.";
    }
    finally
    {
        guardando = false;
    }
}
```

Muestra mensajes claros al usuario, pero no presentes stack traces ni detalles internos de la API.

## 16. Checklist de pruebas

### Alta

- Código obligatorio y único.
- URL válida.
- Enrollment obligatorio.
- CodeCamera numérico y positivo.
- Se muestra confirmación después de guardar.
- La tabla se actualiza sin recargar manualmente.

### Edición

- Se carga el registro correcto.
- El ID no puede cambiarse desde el formulario.
- Se envían todos los campos requeridos por el endpoint.
- Se conserva el certificado existente si no se modifica.

### Activación y desactivación

- Aparece confirmación.
- Se utiliza el ID y enrollment del registro seleccionado.
- El botón cambia según el estado actual.
- Se actualiza el badge después de la respuesta.
- Un usuario sin permiso recibe 403 y no cambia la UI local.

### Certificado

- KeyName, ThumbPrint, Serial, PublicToken, Enrollment y Subject son requeridos.
- El token no aparece en la tabla.
- El token no aparece en logs.
- El modal permite cancelar sin guardar.
- Se muestra el certificado como registrado después de una respuesta exitosa.

### Accesibilidad

- Todos los modales tienen `role="dialog"`.
- Confirmaciones críticas usan `role="alertdialog"`.
- Cada campo tiene `label` asociado.
- Los botones tienen texto o `aria-label`.
- Escape y clic fuera pueden cerrar solo modales no críticos.
- El foco debe moverse al modal al abrirse y regresar al botón de origen al cerrarse.

## 17. Flujo visual recomendado

1. Lista de participantes con acciones compactas.
2. Botón verde para alta.
3. Botón azul para detalle.
4. Botón naranja para edición.
5. Botón navy para estado.
6. Certificado visible únicamente como estado registrado/no registrado.
7. Registro de certificado en modal naranja, siguiendo la referencia compartida.
8. Información técnica completa únicamente en detalle o edición autorizada.

Esta separación mantiene la tabla limpia, reduce errores operativos y evita exponer información técnica o criptográfica sin necesidad.
