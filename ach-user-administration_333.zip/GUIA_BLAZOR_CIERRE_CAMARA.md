# Guía de implementación Blazor: Cierre de Cámara

## 1. Objetivo

Esta guía describe cómo implementar en Blazor la pantalla de **Cierre de Cámara ACH**, incluyendo:

- Consulta de ciclos de cámara.
- Filtros por fecha, ciclo y participante.
- Activación global de filtros.
- Visualización de importes por participante.
- Detalle de un registro de cámara.
- Cierre de un ciclo con confirmación.
- Reproceso de un ciclo fuera de la tabla de registros.
- Estados de ciclo: abierto, cerrado y con observaciones.
- Paginación y cantidad de registros visibles.

La implementación propuesta funciona para **Blazor Server** y **Blazor WebAssembly**, usando un servicio HTTP desacoplado.

---

## 2. Estructura recomendada

```text
Features/
└── CierreCamara/
    ├── Models/
    │   ├── CierreCamaraDto.cs
    │   ├── CierreCamaraFilter.cs
    │   ├── CierreCamaraResult.cs
    │   └── ReprocesarCicloRequest.cs
    ├── Services/
    │   ├── ICierreCamaraService.cs
    │   └── CierreCamaraService.cs
    └── Pages/
        ├── CierreCamara.razor
        └── CierreCamara.razor.cs

Shared/
└── Components/
    ├── Modal.razor
    └── LoadingIndicator.razor
```

Para una aplicación pequeña también puedes colocar los archivos en:

```text
Pages/CierreCamara.razor
Models/CierreCamaraDto.cs
Services/CierreCamaraService.cs
```

---

## 3. Modelo principal

Crea `Models/CierreCamaraDto.cs`:

```csharp
namespace BcpAch.Models;

public sealed class CierreCamaraDto
{
    public long Id { get; set; }
    public string Participante { get; set; } = string.Empty;
    public DateTime Fecha { get; set; }
    public string DireccionFlujo { get; set; } = string.Empty;
    public string Tipo { get; set; } = "QR";
    public int NumeroCamaraAch { get; set; }
    public string Moneda { get; set; } = "BOB";
    public decimal Total { get; set; }
    public int OperacionesPorCiclo { get; set; }
    public string Estado { get; set; } = string.Empty;
    public string Ciclo { get; set; } = string.Empty;
    public string UsuarioCierre { get; set; } = string.Empty;
    public DateTime? FechaCierre { get; set; }
    public string Observaciones { get; set; } = string.Empty;
}
```

### Estados sugeridos

```csharp
public static class EstadosCierreCamara
{
    public const string Abierta = "Abierta";
    public const string Cerrada = "Cerrada";
    public const string ConObservaciones = "Con observaciones";
    public const string EnProceso = "En proceso";
    public const string Error = "Error";
}
```

No dependas de comparaciones dispersas como `Estado == "Cerrada"` en todos los componentes. Centraliza los estados para evitar errores de escritura y facilitar futuros cambios.

---

## 4. Modelo de filtros

Crea `Models/CierreCamaraFilter.cs`:

```csharp
namespace BcpAch.Models;

public sealed class CierreCamaraFilter
{
    public bool FiltrosActivos { get; set; }
    public DateTime? Fecha { get; set; }
    public string? Ciclo { get; set; }
    public string? Participante { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
```

El campo `FiltrosActivos` permite controlar globalmente los filtros. Cuando es `false`, el backend debe ignorar fecha, ciclo y participante.

---

## 5. Respuesta paginada

Crea `Models/CierreCamaraResult.cs`:

```csharp
namespace BcpAch.Models;

public sealed class CierreCamaraResult
{
    public IReadOnlyList<CierreCamaraDto> Items { get; init; } = [];
    public int TotalRegistros { get; init; }
    public int Page { get; init; }
    public int PageSize { get; init; }

    public int TotalPaginas =>
        PageSize <= 0 ? 0 : (int)Math.Ceiling((double)TotalRegistros / PageSize);
}
```

---

## 6. Requests de cierre y reproceso

Crea `Models/ReprocesarCicloRequest.cs`:

```csharp
namespace BcpAch.Models;

public sealed class CerrarCicloRequest
{
    public string Ciclo { get; set; } = string.Empty;
    public string? Observaciones { get; set; }
}

public sealed class ReprocesarCicloRequest
{
    public string Ciclo { get; set; } = string.Empty;
    public string Motivo { get; set; } = string.Empty;
}

public sealed class OperacionResponse
{
    public bool Exitoso { get; set; }
    public string Mensaje { get; set; } = string.Empty;
    public string? CorrelationId { get; set; }
}
```

El `CorrelationId` es importante para rastrear cierres y reprocesos en auditoría.

---

## 7. Contrato del servicio

Crea `Services/ICierreCamaraService.cs`:

```csharp
using BcpAch.Models;

namespace BcpAch.Services;

public interface ICierreCamaraService
{
    Task<CierreCamaraResult> ObtenerAsync(
        CierreCamaraFilter filtro,
        CancellationToken cancellationToken = default);

    Task<CierreCamaraDto?> ObtenerDetalleAsync(
        long id,
        CancellationToken cancellationToken = default);

    Task<OperacionResponse> CerrarCicloAsync(
        CerrarCicloRequest request,
        CancellationToken cancellationToken = default);

    Task<OperacionResponse> ReprocesarCicloAsync(
        ReprocesarCicloRequest request,
        CancellationToken cancellationToken = default);
}
```

---

## 8. Servicio HTTP

Crea `Services/CierreCamaraService.cs`:

```csharp
using System.Net.Http.Json;
using BcpAch.Models;

namespace BcpAch.Services;

public sealed class CierreCamaraService : ICierreCamaraService
{
    private readonly HttpClient _httpClient;

    public CierreCamaraService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<CierreCamaraResult> ObtenerAsync(
        CierreCamaraFilter filtro,
        CancellationToken cancellationToken = default)
    {
        var query = new List<string>
        {
            $"page={filtro.Page}",
            $"pageSize={filtro.PageSize}",
            $"filtrosActivos={filtro.FiltrosActivos.ToString().ToLowerInvariant()}"
        };

        if (filtro.FiltrosActivos && filtro.Fecha.HasValue)
            query.Add($"fecha={filtro.Fecha.Value:yyyy-MM-dd}");

        if (filtro.FiltrosActivos && !string.IsNullOrWhiteSpace(filtro.Ciclo))
            query.Add($"ciclo={Uri.EscapeDataString(filtro.Ciclo)}");

        if (filtro.FiltrosActivos && !string.IsNullOrWhiteSpace(filtro.Participante))
            query.Add($"participante={Uri.EscapeDataString(filtro.Participante)}");

        var url = $"api/cierre-camara?{string.Join("&", query)}";
        return await _httpClient.GetFromJsonAsync<CierreCamaraResult>(url, cancellationToken)
            ?? new CierreCamaraResult();
    }

    public Task<CierreCamaraDto?> ObtenerDetalleAsync(
        long id,
        CancellationToken cancellationToken = default)
    {
        return _httpClient.GetFromJsonAsync<CierreCamaraDto>(
            $"api/cierre-camara/{id}", cancellationToken);
    }

    public async Task<OperacionResponse> CerrarCicloAsync(
        CerrarCicloRequest request,
        CancellationToken cancellationToken = default)
    {
        using var response = await _httpClient.PostAsJsonAsync(
            "api/cierre-camara/cerrar",
            request,
            cancellationToken);

        return await response.Content.ReadFromJsonAsync<OperacionResponse>(cancellationToken: cancellationToken)
            ?? new OperacionResponse { Mensaje = "No se recibió respuesta del servidor." };
    }

    public async Task<OperacionResponse> ReprocesarCicloAsync(
        ReprocesarCicloRequest request,
        CancellationToken cancellationToken = default)
    {
        using var response = await _httpClient.PostAsJsonAsync(
            "api/cierre-camara/reprocesar",
            request,
            cancellationToken);

        return await response.Content.ReadFromJsonAsync<OperacionResponse>(cancellationToken: cancellationToken)
            ?? new OperacionResponse { Mensaje = "No se recibió respuesta del servidor." };
    }
}
```

### Registro del servicio

En `Program.cs`:

```csharp
builder.Services.AddScoped<ICierreCamaraService, CierreCamaraService>();
```

Si usas Blazor WebAssembly, registra también el `HttpClient`:

```csharp
builder.Services.AddScoped(sp => new HttpClient
{
    BaseAddress = new Uri(builder.HostEnvironment.BaseAddress)
});
```

En Blazor Server, configura el `BaseAddress` de acuerdo con tu API:

```csharp
builder.Services.AddHttpClient<ICierreCamaraService, CierreCamaraService>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["ApiBaseUrl"]!);
});
```

---

## 9. Página Razor

Crea `Pages/CierreCamara.razor`:

```razor
@page "/cierre-camara"
@using BcpAch.Models
@inject ICierreCamaraService CierreService

<PageTitle>Cierre de Cámara</PageTitle>

<div class="page-shell">
    <div class="page-heading">
        <h1>Cierre de Cámara</h1>
        <p>Visualiza los importes de liquidación por participante.</p>
    </div>

    <section class="filter-card" aria-labelledby="filters-title">
        <div class="filter-heading">
            <h2 id="filters-title">Filtros de búsqueda</h2>
            <label class="global-filter-toggle">
                <input type="checkbox" @bind="Filtro.FiltrosActivos" />
                Activar filtros
            </label>
        </div>

        <div class="filter-grid">
            <label>
                <span>Fecha</span>
                <InputDate @bind-Value="Filtro.Fecha"
                           class="form-control"
                           disabled="@(!Filtro.FiltrosActivos)" />
            </label>

            <label>
                <span>Ciclo</span>
                <InputSelect @bind-Value="Filtro.Ciclo"
                             class="form-control"
                             disabled="@(!Filtro.FiltrosActivos)">
                    <option value="">-- Todos --</option>
                    @foreach (var ciclo in Ciclos)
                    {
                        <option value="@ciclo">@ciclo</option>
                    }
                </InputSelect>
            </label>

            <label>
                <span>Participante</span>
                <InputSelect @bind-Value="Filtro.Participante"
                             class="form-control"
                             disabled="@(!Filtro.FiltrosActivos)">
                    <option value="">-- Todos --</option>
                    @foreach (var participante in Participantes)
                    {
                        <option value="@participante">@participante</option>
                    }
                </InputSelect>
            </label>

            <div class="filter-actions">
                <button class="btn btn-primary" @onclick="BuscarAsync" disabled="@Cargando">
                    Buscar
                </button>
                <button class="btn btn-outline" @onclick="LimpiarFiltrosAsync" disabled="@Cargando">
                    Limpiar
                </button>
            </div>
        </div>
    </section>

    <section class="reprocess-card" aria-labelledby="reprocess-title">
        <div>
            <h2 id="reprocess-title">Reprocesar cierre por ciclo</h2>
            <p>Selecciona un ciclo cerrado para volver a ejecutar su conciliación.</p>
        </div>

        <div class="reprocess-controls">
            <label>
                <span>Ciclo</span>
                <InputSelect @bind-Value="CicloReproceso" class="form-control">
                    <option value="">Selecciona un ciclo</option>
                    @foreach (var ciclo in CiclosCerrados)
                    {
                        <option value="@ciclo.Ciclo">@ciclo.Ciclo · @ciclo.Fecha.ToString("dd/MM/yyyy")</option>
                    }
                </InputSelect>
            </label>

            <button class="btn btn-purple"
                    @onclick="AbrirModalReproceso"
                    disabled="@(string.IsNullOrWhiteSpace(CicloReproceso))">
                Reprocesar ciclo
            </button>
        </div>
    </section>

    @if (Cargando)
    {
        <div class="loading-state" role="status">Cargando registros...</div>
    }
    else if (!string.IsNullOrWhiteSpace(Error))
    {
        <div class="error-state" role="alert">@Error</div>
    }
    else
    {
        <section class="table-card">
            <div class="table-toolbar">
                <div>
                    <label>Mostrar</label>
                    <select @bind="Filtro.PageSize" @bind:after="BuscarAsync">
                        <option value="20">20</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span>registros</span>
                </div>
                <strong>Total de registros: @Resultado.TotalRegistros</strong>
            </div>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Participante</th>
                            <th>Fecha</th>
                            <th>Dirección de flujo</th>
                            <th>Tipo</th>
                            <th>Número de cámara ACH</th>
                            <th>Moneda</th>
                            <th>Total</th>
                            <th>Operaciones por ciclo</th>
                            <th>Estado</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach (var registro in Resultado.Items)
                        {
                            <tr>
                                <td>@registro.Participante</td>
                                <td>@registro.Fecha.ToString("yyyy-MM-dd")</td>
                                <td>@registro.DireccionFlujo</td>
                                <td>@registro.Tipo</td>
                                <td>@registro.NumeroCamaraAch</td>
                                <td>@registro.Moneda</td>
                                <td class="amount">@registro.Total.ToString("N2")</td>
                                <td>@registro.OperacionesPorCiclo</td>
                                <td><span class="status-badge @GetStatusClass(registro.Estado)">@registro.Estado</span></td>
                                <td>
                                    <button class="icon-button" @onclick="() => AbrirDetalle(registro)" aria-label="Ver detalle">
                                        Ver
                                    </button>
                                </td>
                            </tr>
                        }
                    </tbody>
                </table>
            </div>

            <div class="pagination">
                <button class="btn btn-outline" @onclick="PaginaAnteriorAsync" disabled="@(Filtro.Page <= 1)">Anterior</button>
                <span>Página @Resultado.Page de @Resultado.TotalPaginas</span>
                <button class="btn btn-outline" @onclick="PaginaSiguienteAsync" disabled="@(Filtro.Page >= Resultado.TotalPaginas)">Siguiente</button>
            </div>
        </section>
    }
</div>

@if (Detalle is not null)
{
    <div class="modal-backdrop" @onclick="CerrarDetalle">
        <div class="modal-panel modal-large" @onclick:stopPropagation="true" role="dialog" aria-modal="true">
            <div class="modal-header blue-header">
                <div>
                    <h2>Detalle de cámara</h2>
                    <span>@Detalle.Ciclo</span>
                </div>
                <button class="modal-close" @onclick="CerrarDetalle" aria-label="Cerrar">×</button>
            </div>
            <div class="detail-grid">
                <DetailItem Label="Participante" Value="@Detalle.Participante" />
                <DetailItem Label="Fecha" Value="@Detalle.Fecha.ToString("dd/MM/yyyy")" />
                <DetailItem Label="Dirección de flujo" Value="@Detalle.DireccionFlujo" />
                <DetailItem Label="Tipo" Value="@Detalle.Tipo" />
                <DetailItem Label="Moneda" Value="@Detalle.Moneda" />
                <DetailItem Label="Total" Value="@Detalle.Total.ToString("N2")" />
                <DetailItem Label="Usuario cierre" Value="@Detalle.UsuarioCierre" />
                <DetailItem Label="Observaciones" Value="@Detalle.Observaciones" />
            </div>
        </div>
    </div>
}

@if (MostrarModalReproceso)
{
    <div class="modal-backdrop" @onclick="CerrarModalReproceso">
        <div class="modal-panel" @onclick:stopPropagation="true" role="dialog" aria-modal="true" aria-labelledby="reprocess-modal-title">
            <div class="modal-header purple-header">
                <div>
                    <h2 id="reprocess-modal-title">Reprocesar cierre de ciclo</h2>
                    <span>@CicloReproceso</span>
                </div>
                <button class="modal-close" @onclick="CerrarModalReproceso" aria-label="Cerrar">×</button>
            </div>
            <div class="modal-body">
                <p>Se volverán a procesar las operaciones y la conciliación del ciclo seleccionado.</p>
                <label>
                    <span>Motivo del reproceso</span>
                    <InputTextArea @bind-Value="MotivoReproceso"
                                   class="form-control textarea"
                                   placeholder="Describe por qué se requiere el reproceso" />
                </label>
                <div class="warning-box">
                    La operación quedará registrada en la auditoría y generará una nueva trazabilidad.
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" @onclick="CerrarModalReproceso">Cancelar</button>
                <button class="btn btn-purple" @onclick="ReprocesarAsync" disabled="@Procesando">
                    @(Procesando ? "Procesando..." : "Confirmar reproceso")
                </button>
            </div>
        </div>
    </div>
}
```

---

## 10. Code-behind

Crea `Pages/CierreCamara.razor.cs`:

```csharp
using BcpAch.Models;
using BcpAch.Services;
using Microsoft.AspNetCore.Components;

namespace BcpAch.Pages;

public partial class CierreCamara : ComponentBase
{
    [Inject]
    protected ICierreCamaraService CierreService { get; set; } = default!;

    protected CierreCamaraFilter Filtro { get; set; } = new()
    {
        FiltrosActivos = false,
        Fecha = DateTime.Today
    };

    protected CierreCamaraResult Resultado { get; set; } = new();
    protected CierreCamaraDto? Detalle { get; set; }
    protected string CicloReproceso { get; set; } = string.Empty;
    protected string MotivoReproceso { get; set; } = string.Empty;
    protected bool MostrarModalReproceso { get; set; }
    protected bool Cargando { get; set; }
    protected bool Procesando { get; set; }
    protected string Error { get; set; } = string.Empty;

    protected List<string> Ciclos { get; } = [];
    protected List<string> Participantes { get; } = [];
    protected List<CierreCamaraDto> CiclosCerrados { get; } = [];

    protected override async Task OnInitializedAsync()
    {
        await BuscarAsync();
    }

    protected async Task BuscarAsync()
    {
        try
        {
            Cargando = true;
            Error = string.Empty;
            Resultado = await CierreService.ObtenerAsync(Filtro);
            ActualizarOpciones(Resultado.Items);
        }
        catch (Exception ex)
        {
            Error = "No fue posible cargar los registros de cierre de cámara.";
            Console.Error.WriteLine(ex);
        }
        finally
        {
            Cargando = false;
        }
    }

    protected async Task LimpiarFiltrosAsync()
    {
        Filtro = new CierreCamaraFilter
        {
            FiltrosActivos = false,
            Fecha = DateTime.Today,
            PageSize = Filtro.PageSize
        };

        CicloReproceso = string.Empty;
        await BuscarAsync();
    }

    protected void ActualizarOpciones(IEnumerable<CierreCamaraDto> registros)
    {
        Ciclos.Clear();
        Participantes.Clear();
        CiclosCerrados.Clear();

        Ciclos.AddRange(registros.Select(x => x.Ciclo).Distinct().OrderByDescending(x => x));
        Participantes.AddRange(registros.Select(x => x.Participante).Distinct().OrderBy(x => x));
        CiclosCerrados.AddRange(registros
            .Where(x => x.Estado.Equals(EstadosCierreCamara.Cerrada, StringComparison.OrdinalIgnoreCase))
            .GroupBy(x => x.Ciclo)
            .Select(x => x.First()));
    }

    protected void AbrirDetalle(CierreCamaraDto registro)
    {
        Detalle = registro;
    }

    protected void CerrarDetalle()
    {
        Detalle = null;
    }

    protected void AbrirModalReproceso()
    {
        if (!string.IsNullOrWhiteSpace(CicloReproceso))
        {
            MostrarModalReproceso = true;
            MotivoReproceso = string.Empty;
        }
    }

    protected void CerrarModalReproceso()
    {
        if (!Procesando)
            MostrarModalReproceso = false;
    }

    protected async Task ReprocesarAsync()
    {
        if (string.IsNullOrWhiteSpace(CicloReproceso) || string.IsNullOrWhiteSpace(MotivoReproceso))
            return;

        try
        {
            Procesando = true;
            var resultado = await CierreService.ReprocesarCicloAsync(new ReprocesarCicloRequest
            {
                Ciclo = CicloReproceso,
                Motivo = MotivoReproceso.Trim()
            });

            if (!resultado.Exitoso)
            {
                Error = resultado.Mensaje;
                return;
            }

            MostrarModalReproceso = false;
            CicloReproceso = string.Empty;
            MotivoReproceso = string.Empty;
            Filtro.Page = 1;
            await BuscarAsync();
        }
        catch (Exception ex)
        {
            Error = "No fue posible reprocesar el ciclo seleccionado.";
            Console.Error.WriteLine(ex);
        }
        finally
        {
            Procesando = false;
        }
    }

    protected async Task PaginaAnteriorAsync()
    {
        if (Filtro.Page > 1)
        {
            Filtro.Page--;
            await BuscarAsync();
        }
    }

    protected async Task PaginaSiguienteAsync()
    {
        if (Filtro.Page < Resultado.TotalPaginas)
        {
            Filtro.Page++;
            await BuscarAsync();
        }
    }

    protected static string GetStatusClass(string estado) => estado switch
    {
        EstadosCierreCamara.Cerrada => "status-success",
        EstadosCierreCamara.ConObservaciones => "status-warning",
        EstadosCierreCamara.Error => "status-error",
        _ => "status-open"
    };
}
```

---

## 11. Componente DetailItem

Puedes crear `Shared/Components/DetailItem.razor`:

```razor
<div class="detail-item">
    <span>@Label</span>
    <strong>@Value</strong>
</div>

@code {
    [Parameter] public string Label { get; set; } = string.Empty;
    [Parameter] public string Value { get; set; } = string.Empty;
}
```

Agrega en `_Imports.razor`:

```razor
@using BcpAch.Shared.Components
@using BcpAch.Services
@using BcpAch.Models
```

---

## 12. API sugerida

### Obtener registros

```http
GET /api/cierre-camara?page=1&pageSize=20&filtrosActivos=true&fecha=2026-08-16&ciclo=CIC-20260816-01&participante=BANCO%20SOL
```

Cuando `filtrosActivos=false`, el servidor debe ignorar los valores enviados en fecha, ciclo y participante.

### Obtener detalle

```http
GET /api/cierre-camara/1001
```

### Cerrar ciclo

```http
POST /api/cierre-camara/cerrar
Content-Type: application/json

{
  "ciclo": "CIC-20260816-01",
  "observaciones": "Cierre conciliado"
}
```

### Reprocesar ciclo

```http
POST /api/cierre-camara/reprocesar
Content-Type: application/json

{
  "ciclo": "CIC-20260810-03",
  "motivo": "Reconciliación solicitada por operaciones"
}
```

Respuesta recomendada:

```json
{
  "exitoso": true,
  "mensaje": "El ciclo fue enviado a reproceso.",
  "correlationId": "RP-20260816-00045"
}
```

---

## 13. Controlador ASP.NET Core de ejemplo

```csharp
[ApiController]
[Route("api/cierre-camara")]
public sealed class CierreCamaraController : ControllerBase
{
    private readonly ICierreCamaraApplicationService _service;

    public CierreCamaraController(ICierreCamaraApplicationService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<ActionResult<CierreCamaraResult>> Obtener(
        [FromQuery] CierreCamaraFilter filtro,
        CancellationToken cancellationToken)
    {
        var resultado = await _service.ObtenerAsync(filtro, cancellationToken);
        return Ok(resultado);
    }

    [HttpPost("cerrar")]
    public async Task<ActionResult<OperacionResponse>> Cerrar(
        [FromBody] CerrarCicloRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Ciclo))
            return BadRequest(new OperacionResponse { Mensaje = "El ciclo es obligatorio." });

        var resultado = await _service.CerrarAsync(request, cancellationToken);
        return resultado.Exitoso ? Ok(resultado) : Conflict(resultado);
    }

    [HttpPost("reprocesar")]
    public async Task<ActionResult<OperacionResponse>> Reprocesar(
        [FromBody] ReprocesarCicloRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Ciclo))
            return BadRequest(new OperacionResponse { Mensaje = "El ciclo es obligatorio." });

        if (string.IsNullOrWhiteSpace(request.Motivo))
            return BadRequest(new OperacionResponse { Mensaje = "El motivo es obligatorio." });

        var resultado = await _service.ReprocesarAsync(request, cancellationToken);
        return resultado.Exitoso ? Ok(resultado) : Conflict(resultado);
    }
}
```

---

## 14. CSS BCP

Agrega estos estilos en `wwwroot/css/app.css`:

```css
:root {
    --bcp-navy: #001b41;
    --bcp-blue: #0061bd;
    --bcp-orange: #ff6600;
    --bcp-purple: #7c3aed;
    --surface: #ffffff;
    --page-background: #f5f7fa;
    --border: #e5e7eb;
    --muted: #64748b;
}

.page-shell {
    min-height: 100vh;
    padding: 2rem;
    background: var(--page-background);
}

.page-heading {
    margin-bottom: 1.75rem;
}

.page-heading h1 {
    margin: 0;
    color: var(--bcp-navy);
    font-size: 2.25rem;
    font-weight: 700;
}

.page-heading p,
.filter-card p,
.reprocess-card p {
    margin: .5rem 0 0;
    color: var(--muted);
}

.filter-card,
.reprocess-card,
.table-card {
    border: 1px solid var(--border);
    border-radius: .75rem;
    background: var(--surface);
    box-shadow: 0 1px 3px rgb(15 23 42 / 8%);
}

.filter-card,
.reprocess-card {
    margin-bottom: 1.5rem;
    padding: 1.25rem;
}

.filter-heading,
.reprocess-card,
.table-toolbar,
.pagination,
.modal-header,
.modal-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
}

.filter-heading h2,
.reprocess-card h2 {
    margin: 0;
    color: var(--bcp-navy);
    font-size: 1rem;
}

.global-filter-toggle {
    display: flex;
    align-items: center;
    gap: .5rem;
    color: var(--bcp-navy);
    font-size: .875rem;
    font-weight: 600;
}

.filter-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 1rem;
    margin-top: 1rem;
}

.filter-grid label,
.reprocess-controls label,
.modal-body label {
    display: flex;
    flex-direction: column;
    gap: .4rem;
    color: var(--bcp-navy);
    font-size: .875rem;
    font-weight: 600;
}

.form-control,
.filter-grid select,
.filter-grid input,
.reprocess-controls select,
.table-toolbar select {
    min-height: 2.5rem;
    border: 1px solid #cbd5e1;
    border-radius: .5rem;
    padding: .5rem .75rem;
    color: #1e293b;
    background: white;
    outline: none;
}

.form-control:focus,
.filter-grid select:focus,
.filter-grid input:focus {
    border-color: var(--bcp-blue);
    box-shadow: 0 0 0 3px rgb(0 97 189 / 15%);
}

.filter-actions,
.reprocess-controls {
    display: flex;
    align-items: end;
    gap: .75rem;
}

.btn {
    min-height: 2.5rem;
    border: 1px solid transparent;
    border-radius: .5rem;
    padding: .55rem 1.25rem;
    font-weight: 600;
    cursor: pointer;
}

.btn:disabled {
    cursor: not-allowed;
    opacity: .5;
}

.btn-primary {
    color: white;
    background: var(--bcp-blue);
}

.btn-outline {
    border-color: #94a3b8;
    color: #475569;
    background: white;
}

.btn-purple {
    color: white;
    background: var(--bcp-purple);
}

.table-card {
    overflow: hidden;
}

.table-toolbar,
.pagination {
    padding: 1rem 1.25rem;
}

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    min-width: 1150px;
    border-collapse: collapse;
}

thead {
    color: white;
    background: linear-gradient(90deg, var(--bcp-navy), var(--bcp-blue));
}

th,
td {
    padding: .9rem 1rem;
    border-bottom: 1px solid #eef2f7;
    text-align: left;
    white-space: nowrap;
}

th {
    font-size: .75rem;
    text-transform: uppercase;
}

tbody tr:hover {
    background: #eff6ff;
}

.amount {
    font-variant-numeric: tabular-nums;
}

.status-badge {
    display: inline-flex;
    border-radius: 999px;
    padding: .35rem .75rem;
    font-size: .75rem;
    font-weight: 700;
}

.status-success { color: #15803d; background: #dcfce7; }
.status-warning { color: #b45309; background: #fef3c7; }
.status-error { color: #b91c1c; background: #fee2e2; }
.status-open { color: #c2410c; background: #fff4ed; }

.icon-button {
    border: 0;
    border-radius: .45rem;
    padding: .45rem .7rem;
    color: white;
    background: var(--bcp-blue);
    cursor: pointer;
}

.modal-backdrop {
    position: fixed;
    inset: 0;
    z-index: 50;
    display: grid;
    place-items: center;
    padding: 1rem;
    background: rgb(15 23 42 / 60%);
}

.modal-panel {
    width: min(100%, 34rem);
    overflow: hidden;
    border-radius: 1rem;
    background: white;
    box-shadow: 0 20px 50px rgb(15 23 42 / 25%);
}

.modal-large {
    width: min(100%, 44rem);
}

.modal-header {
    padding: 1.25rem 1.5rem;
    color: white;
}

.modal-header h2 {
    margin: 0;
    font-size: 1.2rem;
}

.modal-header span {
    display: block;
    margin-top: .25rem;
    color: #dbeafe;
    font-size: .8rem;
}

.blue-header { background: linear-gradient(90deg, var(--bcp-navy), var(--bcp-blue)); }
.purple-header { background: var(--bcp-purple); }

.modal-close {
    border: 0;
    color: white;
    background: transparent;
    font-size: 1.75rem;
    cursor: pointer;
}

.modal-body,
.modal-footer,
.detail-grid {
    padding: 1.5rem;
}

.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1.25rem;
}

.detail-item {
    display: flex;
    flex-direction: column;
    gap: .35rem;
}

.detail-item span {
    color: var(--bcp-orange);
    font-size: .72rem;
    font-weight: 800;
    text-transform: uppercase;
}

.detail-item strong {
    color: var(--bcp-navy);
}

.textarea {
    min-height: 7rem;
    resize: vertical;
}

.warning-box {
    margin-top: 1rem;
    border-radius: .5rem;
    padding: .8rem;
    color: #5b21b6;
    background: #f5f3ff;
    font-size: .8rem;
}

.loading-state,
.error-state {
    padding: 2rem;
    text-align: center;
}

.error-state {
    color: #b91c1c;
    background: #fee2e2;
}

@media (max-width: 900px) {
    .filter-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .reprocess-card,
    .reprocess-controls {
        align-items: stretch;
        flex-direction: column;
    }
}

@media (max-width: 600px) {
    .page-shell {
        padding: 1rem;
    }

    .page-heading h1 {
        font-size: 1.75rem;
    }

    .filter-heading,
    .table-toolbar,
    .pagination {
        align-items: stretch;
        flex-direction: column;
    }

    .filter-grid,
    .detail-grid {
        grid-template-columns: 1fr;
    }

    .filter-actions {
        width: 100%;
    }

    .filter-actions .btn {
        flex: 1;
    }
}
```

---

## 15. Reglas de negocio

### Consulta

1. La fecha por defecto debe ser la fecha actual.
2. Los filtros empiezan desactivados globalmente.
3. Si `FiltrosActivos` es `false`, no se filtra por fecha, ciclo ni participante.
4. Si `FiltrosActivos` es `true`, se aplican únicamente los valores que tengan contenido.
5. El botón Buscar reinicia la página a 1.
6. El cambio de cantidad de registros debe volver a consultar el backend.

### Cierre

1. Solo se puede cerrar un ciclo abierto.
2. El servidor debe validar que el ciclo no haya sido cerrado previamente.
3. El cierre debe registrar usuario, fecha, hora y observaciones.
4. La interfaz debe solicitar confirmación antes de cerrar.
5. No debe permitirse doble envío mientras se procesa la operación.

### Reproceso

1. El reproceso debe iniciarse desde el bloque independiente, no desde la tabla.
2. Solo deben aparecer ciclos cerrados en el selector.
3. El motivo del reproceso es obligatorio.
4. El servidor debe validar que no exista otro reproceso activo para el mismo ciclo.
5. Cada reproceso debe generar un `CorrelationId`.
6. La operación debe ser idempotente o contar con una llave de idempotencia.
7. El usuario debe recibir un mensaje de éxito o error.

---

## 16. Seguridad

- Proteger la ruta con autorización:

```razor
@attribute [Authorize(Policy = "CierreCamara.Read")]
```

- Proteger las acciones de cierre y reproceso con permisos separados:

```csharp
[Authorize(Policy = "CierreCamara.Close")]
[Authorize(Policy = "CierreCamara.Reprocess")]
```

- No confiar en el usuario enviado desde el navegador; obtenerlo desde los claims del servidor.
- Validar ciclo, estado y permisos en el backend.
- Registrar auditoría para cierre, reproceso, fecha, usuario, motivo y resultado.
- No mostrar tokens, certificados ni credenciales en la tabla.
- Usar antiforgery cuando corresponda a la configuración de la API.
- Aplicar límites de longitud al motivo y a los filtros.
- Evitar mensajes de error que expongan detalles internos de base de datos.

---

## 17. Pruebas funcionales

### Filtros

- [ ] La pantalla carga con fecha actual.
- [ ] Los campos están deshabilitados cuando el filtro global está apagado.
- [ ] Activar filtros habilita fecha, ciclo y participante.
- [ ] Buscar sin filtros devuelve todos los registros paginados.
- [ ] Buscar con ciclo devuelve únicamente el ciclo seleccionado.
- [ ] Limpiar desactiva filtros y restablece la consulta.

### Cierre

- [ ] Se puede abrir el detalle de cada registro.
- [ ] Un ciclo abierto muestra la opción de cierre.
- [ ] Un ciclo cerrado no permite cerrarse nuevamente.
- [ ] El cierre solicita confirmación.
- [ ] Se muestra estado de procesamiento.
- [ ] La tabla se actualiza luego de cerrar.

### Reproceso

- [ ] El bloque de reproceso aparece fuera de la tabla.
- [ ] El selector solo muestra ciclos cerrados.
- [ ] El botón está deshabilitado sin ciclo seleccionado.
- [ ] El modal muestra el ciclo elegido.
- [ ] No permite confirmar sin motivo.
- [ ] El botón evita doble envío.
- [ ] Se muestra el mensaje de resultado.
- [ ] La tabla se actualiza después del reproceso.

### Responsive y accesibilidad

- [ ] La tabla tiene desplazamiento horizontal en móvil.
- [ ] Los botones tienen texto o `aria-label`.
- [ ] Los modales tienen `role="dialog"` y `aria-modal="true"`.
- [ ] El foco debe llevarse al modal al abrirlo.
- [ ] Escape debe cerrar el modal cuando no hay una operación activa.
- [ ] Los mensajes de error usan `role="alert"`.

---

## 18. Integración con el menú lateral

Agrega el enlace en el menú:

```razor
<NavLink href="/cierre-camara" Match="NavLinkMatch.All">
    <span class="nav-icon">▣</span>
    <span>Cierre de Cámara</span>
</NavLink>
```

Para mostrar el acceso solo a usuarios autorizados:

```razor
<AuthorizeView Policy="CierreCamara.Read">
    <Authorized>
        <NavLink href="/cierre-camara">
            Cierre de Cámara
        </NavLink>
    </Authorized>
</AuthorizeView>
```

---

## 19. Datos de prueba

```csharp
new CierreCamaraDto
{
    Id = 1,
    Participante = "BANCO SOL",
    Fecha = new DateTime(2026, 8, 14),
    DireccionFlujo = "Neto",
    Tipo = "QR",
    NumeroCamaraAch = 1,
    Moneda = "BOB",
    Total = 50037.34m,
    OperacionesPorCiclo = 110,
    Estado = EstadosCierreCamara.Cerrada,
    Ciclo = "CIC-20260814-01",
    UsuarioCierre = "BC2414",
    FechaCierre = new DateTime(2026, 8, 14, 17, 30, 0),
    Observaciones = "Cierre conciliado"
};
```

---

## 20. Resultado esperado

La pantalla final debe presentar:

1. Menú lateral institucional.
2. Título `Cierre de Camara`.
3. Descripción `Visualiza los importes de liquidacion por participante`.
4. Panel de filtros con activación global.
5. Selector de fecha, ciclo y participante.
6. Botones Buscar y Limpiar.
7. Bloque separado para `Reprocesar cierre por ciclo`.
8. Selector de ciclo cerrado y botón `Reprocesar ciclo`.
9. Tabla con los 10 campos operativos.
10. Modal de detalle.
11. Modal de confirmación de reproceso.
12. Paginación y total de registros.

Esta estructura mantiene la misma organización funcional del proyecto actual y permite reemplazar los datos de prueba por los endpoints reales sin cambiar la interfaz principal.
