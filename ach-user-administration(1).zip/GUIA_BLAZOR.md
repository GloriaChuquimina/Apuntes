# Guía de Implementación en Blazor - Administración de Usuarios

## Resumen de la Interfaz

He creado una interfaz moderna que consiste en:

1. **Tabla Optimizada**: Muestra solo los campos esenciales (Usuario, Email, Celular, Estado, Acción)
2. **Botón de Acción**: Un ícono de ojo que abre el modal de detalle
3. **Modal Profesional**: Despliega todos los datos del usuario en formato limpio

---

## 🎨 Componente Blazor Principal

### EditUsuarios.razor

```razor
@page "/administracion/usuarios"
@using YourApp.Models
@using YourApp.Services
@inject UsuarioService UsuarioService

<div class="admin-container">
    <!-- Header -->
    <div class="admin-header">
        <h1>Administración de Usuarios</h1>
        <p>Gestiona accesos, roles y estado de las cuentas</p>
    </div>

    <!-- Barra de búsqueda y acciones -->
    <div class="search-bar">
        <div class="search-input">
            <input type="text" 
                   placeholder="Buscar por nombre, matrícula o correo..." 
                   @bind="filtro"
                   @oninput="@((ChangeEventArgs e) => FiltrarUsuarios(e.Value?.ToString()))" />
        </div>
        <button class="btn btn-new" @onclick="NuevoUsuario">
            + Nuevo Usuario
        </button>
    </div>

    <!-- Tabla de usuarios -->
    <div class="table-container">
        <table class="usuarios-table">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Email</th>
                    <th>Celular</th>
                    <th>Estado</th>
                    <th class="text-center">Acción</th>
                </tr>
            </thead>
            <tbody>
                @foreach (var usuario in usuariosFiltrados)
                {
                    <tr>
                        <td class="usuario-cell">@usuario.Usuario</td>
                        <td>@usuario.Email</td>
                        <td>@usuario.Celular</td>
                        <td>
                            <span class="badge badge-success">
                                @usuario.Estado
                            </span>
                        </td>
                        <td class="text-center">
                            <button class="btn-action" 
                                    @onclick="@(() => AbrirDetalle(usuario))"
                                    title="Ver detalle">
                                👁️
                            </button>
                        </td>
                    </tr>
                }
            </tbody>
        </table>
    </div>

    <!-- Modal de Detalle -->
    @if (mostrarModal && usuarioSeleccionado != null)
    {
        <div class="modal-overlay" @onclick="CerrarModal"></div>
        <div class="modal">
            <div class="modal-header">
                <div>
                    <h2>Detalle del Usuario</h2>
                    <p>Información completa de @usuarioSeleccionado.Usuario</p>
                </div>
                <button class="btn-close" @onclick="CerrarModal">✕</button>
            </div>

            <div class="modal-body">
                <!-- Columna 1 -->
                <div class="modal-grid">
                    <div class="modal-column">
                        <div class="info-item">
                            <label>Usuario</label>
                            <p>@usuarioSeleccionado.Usuario</p>
                        </div>
                        <div class="info-item">
                            <label>Key Name</label>
                            <p>@usuarioSeleccionado.KeyName</p>
                        </div>
                        <div class="info-item">
                            <label>Email</label>
                            <p>@usuarioSeleccionado.Email</p>
                        </div>
                        <div class="info-item">
                            <label>Celular</label>
                            <p>@usuarioSeleccionado.Celular</p>
                        </div>
                    </div>

                    <!-- Columna 2 -->
                    <div class="modal-column">
                        <div class="info-item">
                            <label>Número de Documento</label>
                            <p>@usuarioSeleccionado.NumeroDocumento</p>
                        </div>
                        <div class="info-item">
                            <label>Estado</label>
                            <span class="badge badge-success">✓ @usuarioSeleccionado.Estado</span>
                        </div>
                        <div class="info-item">
                            <label>Usuario Creador</label>
                            <p>@usuarioSeleccionado.UsuarioCreador</p>
                        </div>
                        <div class="info-item">
                            <label>Usuario Modificador</label>
                            <p>@usuarioSeleccionado.UsuarioModificador</p>
                        </div>
                    </div>
                </div>

                <!-- Sección de Auditoría -->
                <hr class="modal-divider" />
                <h3>Información de Auditoría</h3>
                <div class="audit-grid">
                    <div>
                        <label>Fecha de Creación</label>
                        <p>@usuarioSeleccionado.FechaCreacion?.ToString("yyyy-MM-dd")</p>
                    </div>
                    <div>
                        <label>Fecha de Modificación</label>
                        <p>@usuarioSeleccionado.FechaModificacion?.ToString("yyyy-MM-dd")</p>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" @onclick="CerrarModal">Cerrar</button>
                <button class="btn btn-primary" @onclick="@(() => Editar(usuarioSeleccionado))">
                    ✏️ Editar
                </button>
                <button class="btn btn-danger" @onclick="@(() => Eliminar(usuarioSeleccionado))">
                    🗑️ Eliminar
                </button>
            </div>
        </div>
    }
</div>

@code {
    private List<UsuarioModel> usuarios = new();
    private List<UsuarioModel> usuariosFiltrados = new();
    private UsuarioModel? usuarioSeleccionado;
    private bool mostrarModal = false;
    private string filtro = "";

    protected override async Task OnInitializedAsync()
    {
        usuarios = await UsuarioService.ObtenerUsuarios();
        usuariosFiltrados = usuarios;
    }

    private void AbrirDetalle(UsuarioModel usuario)
    {
        usuarioSeleccionado = usuario;
        mostrarModal = true;
    }

    private void CerrarModal()
    {
        mostrarModal = false;
        usuarioSeleccionado = null;
    }

    private void FiltrarUsuarios(string? texto)
    {
        filtro = texto ?? "";
        if (string.IsNullOrWhiteSpace(filtro))
        {
            usuariosFiltrados = usuarios;
        }
        else
        {
            usuariosFiltrados = usuarios
                .Where(u => u.Usuario.Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                           u.Email.Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                           u.Celular.Contains(filtro))
                .ToList();
        }
    }

    private async Task NuevoUsuario()
    {
        // Navegar a página de nuevo usuario
    }

    private async Task Editar(UsuarioModel usuario)
    {
        // Lógica para editar
    }

    private async Task Eliminar(UsuarioModel usuario)
    {
        // Lógica para eliminar
    }
}
```

---

## 🎨 Estilos CSS

### EstilosUsuarios.css

```css
:root {
    --primary: #2563eb;
    --primary-dark: #1d4ed8;
    --success: #16a34a;
    --danger: #dc2626;
    --bg-light: #f8fafc;
    --border-light: #e2e8f0;
    --text-dark: #1e293b;
    --text-muted: #64748b;
}

.admin-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    min-height: 100vh;
}

.admin-header {
    margin-bottom: 2rem;
}

.admin-header h1 {
    font-size: 2.25rem;
    font-weight: 700;
    color: var(--text-dark);
    margin: 0 0 0.5rem 0;
}

.admin-header p {
    color: var(--text-muted);
    font-size: 1.125rem;
}

/* Search Bar */
.search-bar {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.search-input {
    flex: 1;
    position: relative;
}

.search-input input {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid var(--border-light);
    border-radius: 0.5rem;
    background: white;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.search-input input:focus {
    outline: none;
    ring: 2px;
    ring-color: var(--primary);
    border-color: var(--primary);
}

.btn-new {
    padding: 0.75rem 1.5rem;
    background: var(--success);
    color: white;
    border: none;
    border-radius: 0.5rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-new:hover {
    background: #15803d;
    box-shadow: 0 4px 12px rgba(22, 163, 74, 0.3);
}

/* Tabla */
.table-container {
    background: white;
    border-radius: 0.75rem;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    border: 1px solid var(--border-light);
}

.usuarios-table {
    width: 100%;
    border-collapse: collapse;
}

.usuarios-table thead {
    background: linear-gradient(90deg, var(--primary) 0%, #1e40af 100%);
}

.usuarios-table th {
    padding: 1rem 1.5rem;
    text-align: left;
    color: white;
    font-weight: 600;
    font-size: 0.875rem;
}

.usuarios-table tbody tr {
    border-bottom: 1px solid var(--border-light);
    transition: background-color 0.2s ease;
}

.usuarios-table tbody tr:hover {
    background-color: #f0f9ff;
}

.usuarios-table td {
    padding: 1rem 1.5rem;
    color: var(--text-dark);
}

.usuario-cell {
    font-weight: 600;
}

.badge {
    display: inline-block;
    padding: 0.375rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
}

.badge-success {
    background-color: #dcfce7;
    color: #166534;
}

.text-center {
    text-align: center;
}

/* Botón de acción */
.btn-action {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 2.5rem;
    height: 2.5rem;
    background: var(--primary);
    color: white;
    border: none;
    border-radius: 0.5rem;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 1.125rem;
}

.btn-action:hover {
    background: var(--primary-dark);
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
    transform: scale(1.05);
}

/* Modal */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 40;
}

.modal {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    border-radius: 1rem;
    box-shadow: 0 20px 25px rgba(0, 0, 0, 0.15);
    width: 90%;
    max-width: 800px;
    max-height: 90vh;
    overflow-y: auto;
    z-index: 50;
}

.modal-header {
    background: linear-gradient(90deg, var(--primary) 0%, #1e40af 100%);
    color: white;
    padding: 1.5rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    border-radius: 1rem 1rem 0 0;
}

.modal-header h2 {
    margin: 0 0 0.25rem 0;
    font-size: 1.5rem;
}

.modal-header p {
    margin: 0;
    opacity: 0.9;
    font-size: 0.875rem;
}

.btn-close {
    background: none;
    border: none;
    color: white;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0;
    width: 2rem;
    height: 2rem;
}

.btn-close:hover {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 0.5rem;
}

.modal-body {
    padding: 2rem;
}

.modal-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
    margin-bottom: 2rem;
}

.modal-column {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.info-item label {
    display: block;
    font-size: 0.75rem;
    font-weight: 700;
    color: var(--primary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 0.5rem;
}

.info-item p {
    margin: 0;
    font-size: 1rem;
    color: var(--text-dark);
    font-weight: 500;
}

.modal-divider {
    border: none;
    border-top: 2px solid var(--border-light);
    margin: 2rem 0;
}

.audit-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
    background: var(--bg-light);
    padding: 1.5rem;
    border-radius: 0.5rem;
}

.audit-grid div label {
    display: block;
    font-size: 0.75rem;
    font-weight: 700;
    color: var(--text-muted);
    text-transform: uppercase;
    margin-bottom: 0.5rem;
}

.audit-grid div p {
    margin: 0;
    font-size: 1rem;
    font-weight: 500;
    color: var(--text-dark);
}

.modal-footer {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    padding: 1rem 2rem;
    background: var(--bg-light);
    border-top: 1px solid var(--border-light);
    border-radius: 0 0 1rem 1rem;
}

/* Botones generales */
.btn {
    padding: 0.5rem 1.5rem;
    border: none;
    border-radius: 0.5rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-primary {
    background: var(--primary);
    color: white;
}

.btn-primary:hover {
    background: var(--primary-dark);
}

.btn-secondary {
    background: transparent;
    color: var(--text-dark);
    border: 1px solid var(--border-light);
}

.btn-secondary:hover {
    background: var(--bg-light);
}

.btn-danger {
    background: var(--danger);
    color: white;
}

.btn-danger:hover {
    background: #b91c1c;
}

/* Responsive */
@media (max-width: 768px) {
    .modal-grid {
        grid-template-columns: 1fr;
    }
    
    .audit-grid {
        grid-template-columns: 1fr;
    }
    
    .search-bar {
        flex-direction: column;
    }
    
    .btn-new {
        width: 100%;
    }
}
```

---

## 📊 Modelo de Datos

### UsuarioModel.cs

```csharp
public class UsuarioModel
{
    public string Id { get; set; }
    public string Usuario { get; set; }
    public string KeyName { get; set; }
    public string Email { get; set; }
    public string Celular { get; set; }
    public string NumeroDocumento { get; set; }
    public string Estado { get; set; }
    public string UsuarioCreador { get; set; }
    public string UsuarioModificador { get; set; }
    public DateTime? FechaCreacion { get; set; }
    public DateTime? FechaModificacion { get; set; }
}
```

---

## 🔑 Características Destacadas

✅ **Tabla Limpia**: Solo muestra los 4 campos esenciales + botón de acción  
✅ **Modal Profesional**: Todos los datos organizados en 2 columnas  
✅ **Información de Auditoría**: Datos de creación y modificación  
✅ **Botones de Acción**: Editar, Eliminar y Cerrar  
✅ **Diseño Responsivo**: Se adapta a móviles y tablets  
✅ **Animaciones Suaves**: Transiciones elegantes  
✅ **Accesibilidad**: Etiquetas correctas y contraste adecuado  

---

## 🚀 Próximos Pasos

1. Copia los estilos CSS en tu archivo `app.css` o en un componente Scoped
2. Reemplaza el servicio `UsuarioService` con tus llamadas reales a API/BD
3. Implementa las funciones de Editar y Eliminar
4. Personaliza los colores según tu marca

¡La interfaz está lista para usar en Blazor!
